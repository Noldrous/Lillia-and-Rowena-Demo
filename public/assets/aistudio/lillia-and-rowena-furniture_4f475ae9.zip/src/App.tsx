import React, { useState, useMemo, useEffect } from 'react';
import { Search, ShoppingBag, User, X } from 'lucide-react';
import {
  CategoryId,
  FURNITURE_CATEGORIES,
  FurnitureCategory,
  FurnitureItem,
  INITIAL_FURNITURE_ITEMS,
  INITIAL_ORDER_RECORDS,
  INITIAL_WORKSHOP_LOGS,
  OrderRecord,
  OrderStatus,
  PaymentStatus,
  WorkshopLogEntry,
  calculateOrderPricing,
  filterFurnitureItems,
} from './utils/furnitureStore';
import { HomepageView } from './components/HomepageView';
import { CategoryDetailModal } from './components/CategoryDetailModal';
import { CartLineItem, OrderDrawerModal } from './components/OrderDrawerModal';
import { UserDashboardView } from './components/UserDashboardView';
import { AdminDashboardView } from './components/AdminDashboardView';
import { LoginPageView } from './components/LoginPageView';

type ActiveView = 'home' | 'user-dashboard' | 'admin-dashboard' | 'login';

export default function App() {
  const [activeView, setActiveView] = useState<ActiveView>('home');
  const [catalog, setCatalog] = useState<FurnitureItem[]>(INITIAL_FURNITURE_ITEMS);
  const [orders, setOrders] = useState<OrderRecord[]>(INITIAL_ORDER_RECORDS);
  const [workshopLogs, setWorkshopLogs] = useState<WorkshopLogEntry[]>(INITIAL_WORKSHOP_LOGS);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, [activeView]);

  // Search & Category filter state on Homepage
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<CategoryId | 'all'>('all');

  // Category / Furniture Detail Modal state
  const [modalCategory, setModalCategory] = useState<FurnitureCategory | null>(null);
  const [modalInitialItem, setModalInitialItem] = useState<FurnitureItem | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState<boolean>(false);

  // Order Inquiry / Commission Drawer state
  const [isOrderDrawerOpen, setIsOrderDrawerOpen] = useState<boolean>(false);
  const [cartItems, setCartItems] = useState<CartLineItem[]>([
    {
      furniture: INITIAL_FURNITURE_ITEMS[0],
      finish: INITIAL_FURNITURE_ITEMS[0].defaultFinish,
      quantity: 1,
    },
  ]);

  // Authenticated session state
  const [currentRole, setCurrentRole] = useState<'client' | 'admin'>('client');
  const [currentUserName, setCurrentUserName] = useState<string>('Rowena Vance');
  const [currentUserEmail, setCurrentUserEmail] = useState<string>(
    'rowena.vance@vancearchitects.com'
  );

  // Filtered furniture items for Homepage catalog section
  const filteredFurniture = useMemo(
    () => filterFurnitureItems(catalog, searchQuery, selectedCategoryFilter),
    [catalog, searchQuery, selectedCategoryFilter]
  );

  // Items belonging to the currently inspected category in the modal
  const modalCategoryItems = useMemo(() => {
    if (modalCategory) {
      return catalog.filter((item) => item.categoryId === modalCategory.id);
    }
    if (modalInitialItem) {
      return catalog.filter((item) => item.categoryId === modalInitialItem.categoryId);
    }
    return [];
  }, [catalog, modalCategory, modalInitialItem]);

  const totalCartCount = useMemo(
    () => cartItems.reduce((sum, item) => sum + item.quantity, 0),
    [cartItems]
  );

  // Handlers for opening Category / Furniture Details Modal
  const handleOpenCategoryModal = (
    category: FurnitureCategory,
    initialItem?: FurnitureItem
  ) => {
    setModalCategory(category);
    setModalInitialItem(initialItem || null);
    setIsDetailModalOpen(true);
  };

  const handleTopBarCategoryClick = (category: FurnitureCategory) => {
    setActiveView('home');
    setSelectedCategoryFilter(category.id);
    handleOpenCategoryModal(category);
  };

  const handleTopBarSearchChange = (value: string) => {
    setSearchQuery(value);
    if (activeView !== 'home') {
      setActiveView('home');
    }
  };

  const handleOpenItemModal = (item: FurnitureItem) => {
    const parentCat =
      FURNITURE_CATEGORIES.find((c) => c.id === item.categoryId) || null;
    setModalCategory(parentCat);
    setModalInitialItem(item);
    setIsDetailModalOpen(true);
  };

  // Handlers for Order Inquiry / Cart
  const handleAddToOrder = (
    item: FurnitureItem,
    finish: string,
    quantity: number
  ) => {
    setCartItems((prev) => {
      const existingIndex = prev.findIndex(
        (line) => line.furniture.id === item.id && line.finish === finish
      );
      if (existingIndex > -1) {
        const updated = [...prev];
        updated[existingIndex] = {
          ...updated[existingIndex],
          quantity: updated[existingIndex].quantity + quantity,
        };
        return updated;
      }
      return [...prev, { furniture: item, finish, quantity }];
    });
  };

  const handleQuickAddToOrder = (item: FurnitureItem, selectedFinish?: string) => {
    handleAddToOrder(item, selectedFinish || item.defaultFinish, 1);
    setIsOrderDrawerOpen(true);
  };

  const handleUpdateCartQuantity = (
    furnitureId: string,
    finish: string,
    delta: number
  ) => {
    setCartItems((prev) =>
      prev
        .map((line) =>
          line.furniture.id === furnitureId && line.finish === finish
            ? { ...line, quantity: line.quantity + delta }
            : line
        )
        .filter((line) => line.quantity > 0)
    );
  };

  const handleRemoveCartItem = (furnitureId: string, finish: string) => {
    setCartItems((prev) =>
      prev.filter(
        (line) => !(line.furniture.id === furnitureId && line.finish === finish)
      )
    );
  };

  const handleSubmitOrder = (payload: {
    clientName: string;
    clientEmail: string;
    clientPhone: string;
    shippingAddress: string;
    notes: string;
  }): string => {
    const pricing = calculateOrderPricing(
      cartItems.map((line) => ({
        unitPrice: line.furniture.price,
        quantity: line.quantity,
      }))
    );

    const newOrderId = `ORD-2026-${851 + orders.length}`;
    const newRecord: OrderRecord = {
      id: newOrderId,
      clientName: payload.clientName,
      clientEmail: payload.clientEmail,
      clientPhone: payload.clientPhone,
      shippingAddress: payload.shippingAddress,
      createdAt: '2026-11-11',
      estimatedDelivery: '2026-12-22',
      status: 'Order Confirmed',
      paymentStatus: 'Deposit Paid (50%)',
      items: cartItems.map((line) => ({
        furnitureId: line.furniture.id,
        sku: line.furniture.sku,
        name: line.furniture.name,
        finish: line.finish,
        quantity: line.quantity,
        unitPrice: line.furniture.price,
      })),
      subtotal: pricing.subtotal,
      whiteGloveFee: pricing.whiteGloveFee,
      totalAmount: pricing.totalAmount,
      craftspersonAssigned: 'Master Joiner Mateo Reyes',
      notes: payload.notes,
    };

    setOrders((prev) => [newRecord, ...prev]);
    setCartItems([]);
    return newOrderId;
  };

  // User Dashboard handlers
  const handleUpdateOrderNotes = (
    orderId: string,
    updatedNotes: string,
    updatedAddress: string
  ) => {
    setOrders((prev) =>
      prev.map((ord) =>
        ord.id === orderId
          ? {
              ...ord,
              notes: updatedNotes || ord.notes,
              shippingAddress: updatedAddress || ord.shippingAddress,
            }
          : ord
      )
    );
  };

  // Admin Dashboard handlers
  const handleUpdateOrderStatus = (orderId: string, newStatus: OrderStatus) => {
    setOrders((prev) =>
      prev.map((ord) => (ord.id === orderId ? { ...ord, status: newStatus } : ord))
    );
  };

  const handleUpdatePaymentStatus = (
    orderId: string,
    newPayment: PaymentStatus
  ) => {
    setOrders((prev) =>
      prev.map((ord) =>
        ord.id === orderId ? { ...ord, paymentStatus: newPayment } : ord
      )
    );
  };

  const handleAdjustStock = (furnitureId: string, delta: number) => {
    setCatalog((prev) =>
      prev.map((item) =>
        item.id === furnitureId
          ? { ...item, stockCount: Math.max(0, item.stockCount + delta) }
          : item
      )
    );
  };

  const handleAddFurnitureRecord = (newItem: FurnitureItem) => {
    setCatalog((prev) => [newItem, ...prev]);
  };

  const handleAddWorkshopLog = (
    newLog: Omit<WorkshopLogEntry, 'id' | 'timestamp'>
  ) => {
    const entry: WorkshopLogEntry = {
      ...newLog,
      id: `LOG-${904 + workshopLogs.length}`,
      timestamp: '2026-11-11 14:20',
    };
    setWorkshopLogs((prev) => [entry, ...prev]);
  };

  // Login handler
  const handleLoginSuccess = (
    role: 'client' | 'admin',
    displayName: string,
    email: string
  ) => {
    setCurrentRole(role);
    setCurrentUserName(displayName);
    setCurrentUserEmail(email);
    setActiveView(role === 'admin' ? 'admin-dashboard' : 'user-dashboard');
  };

  const [showPromoBanner, setShowPromoBanner] = useState<boolean>(true);

  return (
    <div className="min-h-screen flex flex-col surface-ice-canvas text-[#0D1015]">
      {/* TOP CONCIERGE & FINANCING RIBBON IN OBSIDIAN (#0D1015) WITH ELECTRIC AZURE (#0095FF) ACCENTS */}
      {showPromoBanner && (
        <div className="bg-[#0D1015] text-slate-200 border-b border-[#0095FF]/30 text-xs">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-9 flex items-center justify-between gap-4">
            <div className="flex items-center gap-2 truncate">
              <span className="font-semibold text-[#0095FF]">0% APR Financing for 24 Months</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span className="truncate text-slate-300">
                Complimentary White-Glove Delivery &amp; In-Room Placement Over $3,000
              </span>
            </div>
            <div className="flex items-center gap-4 shrink-0">
              <button
                type="button"
                onClick={() => setActiveView('user-dashboard')}
                className="text-[#BCE3FF] hover:text-white font-medium transition-colors cursor-pointer whitespace-nowrap hidden sm:inline"
              >
                Track My Order
              </button>
              <span aria-hidden="true" className="text-slate-600 hidden sm:inline">·</span>
              <button
                type="button"
                onClick={() => setActiveView('admin-dashboard')}
                className="text-slate-300 hover:text-[#0095FF] transition-colors cursor-pointer whitespace-nowrap hidden md:inline"
              >
                Atelier Record Console
              </button>
              <button
                type="button"
                onClick={() => setShowPromoBanner(false)}
                aria-label="Dismiss promotional financing banner"
                className="text-slate-400 hover:text-white p-0.5 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SLEEK FLAGSHIP SHOWROOM TOP NAVIGATION BAR */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-[#BCE3FF] shadow-2xs">
        <div className="max-w-7xl mx-auto flex flex-wrap xl:flex-nowrap items-center justify-between gap-y-3 gap-x-4 px-4 sm:px-6 lg:px-8 py-3.5">
          {/* Top-Left Zone: Brand Logo (navigates to Homepage) + Cart Button + Live Search Bar */}
          <div className="flex items-center gap-3 flex-1 xl:flex-initial min-w-0">
            <a
              href="#top"
              onClick={(e) => {
                e.preventDefault();
                setActiveView('home');
                setSelectedCategoryFilter('all');
              }}
              aria-label="Lillia and Rowena Furniture Homepage"
              className="group flex items-center gap-2.5 text-[#0D1015] hover:text-[#0095FF] transition-colors whitespace-nowrap shrink-0"
            >
              <span
                aria-hidden="true"
                className="w-8 h-8 rounded-lg bg-[#0D1015] border border-[#0095FF] flex items-center justify-center shadow-2xs shrink-0 group-hover:bg-[#0095FF] transition-colors"
              >
                <span className="font-display text-base font-bold text-[#BCE3FF] group-hover:text-white leading-none">
                  LR
                </span>
              </span>
              <span className="font-display text-xl sm:text-2xl font-bold tracking-tight">
                Lillia &amp; Rowena
              </span>
            </a>

            {/* Top-Left Cart Button */}
            <button
              type="button"
              onClick={() => setIsOrderDrawerOpen(true)}
              aria-label={`Cart (${totalCartCount} items)`}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-[#0D1015] bg-[#BCE3FF]/60 hover:bg-[#0095FF] hover:text-white border border-[#0095FF]/40 rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0 tabular-nums"
            >
              <ShoppingBag className="w-3.5 h-3.5 text-[#0095FF] group-hover:text-white" />
              <span>Cart ({totalCartCount})</span>
            </button>

            {/* Top-Left Live Search Bar */}
            <div className="relative flex-1 xl:w-52 max-w-[220px] min-w-[140px]">
              <label htmlFor="topbar-furniture-search" className="sr-only">
                Search furniture in top bar
              </label>
              <Search className="w-3.5 h-3.5 text-[#0095FF] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                id="topbar-furniture-search"
                type="search"
                value={searchQuery}
                onChange={(e) => handleTopBarSearchChange(e.target.value)}
                placeholder="Search sofas, walnut, SKU..."
                className="w-full pl-8 pr-6 py-1.5 text-xs bg-[#F4FAFF] border border-[#BCE3FF] rounded-lg text-[#0D1015] placeholder:text-slate-400 focus:bg-white focus:border-[#0095FF] focus:outline-none transition-colors"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  aria-label="Clear top bar search"
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-[#0D1015] cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* Center Zone: Furniture Categories Bar */}
          <nav
            aria-label="Furniture Categories"
            className="order-3 xl:order-2 w-full xl:w-auto flex items-center justify-start gap-5 lg:gap-7 text-xs sm:text-sm font-medium text-slate-700 pt-2 xl:pt-0 border-t xl:border-t-0 border-[#BCE3FF]/60 overflow-x-auto"
          >
            {FURNITURE_CATEGORIES.map((category) => {
              const isCategoryActive =
                activeView === 'home' && selectedCategoryFilter === category.id;
              return (
                <button
                  key={category.id}
                  type="button"
                  onClick={() => handleTopBarCategoryClick(category)}
                  className={`py-1 transition-colors cursor-pointer whitespace-nowrap shrink-0 border-b-2 ${
                    isCategoryActive
                      ? 'text-[#0095FF] font-semibold border-[#0095FF]'
                      : 'border-transparent hover:text-[#0095FF] hover:border-[#BCE3FF]'
                  }`}
                >
                  {category.name}
                </button>
              );
            })}
          </nav>

          {/* Right Zone: Login Button */}
          <div className="order-2 xl:order-3 flex items-center shrink-0">
            <button
              type="button"
              onClick={() => setActiveView('login')}
              className={`inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0 shadow-2xs ${
                activeView === 'login'
                  ? 'bg-[#0D1015] text-[#BCE3FF] border border-[#0095FF]'
                  : 'bg-[#0095FF] hover:bg-[#007ACC] text-white'
              }`}
            >
              <User className="w-3.5 h-3.5" />
              <span>Login</span>
            </button>
          </div>
        </div>
      </header>

      {/* MAIN VIEWPORT */}
      <main className="flex-1">
        {activeView === 'home' && (
          <HomepageView
            categories={FURNITURE_CATEGORIES}
            allItems={catalog}
            filteredItems={filteredFurniture}
            searchQuery={searchQuery}
            selectedCategoryFilter={selectedCategoryFilter}
            onSearchChange={setSearchQuery}
            onCategoryFilterChange={setSelectedCategoryFilter}
            onOpenCategoryModal={handleOpenCategoryModal}
            onOpenItemModal={handleOpenItemModal}
            onQuickAddToOrder={handleQuickAddToOrder}
            onNavigate={setActiveView}
          />
        )}

        {activeView === 'user-dashboard' && (
          <UserDashboardView
            currentUserName={currentUserName}
            currentUserEmail={currentUserEmail}
            orders={orders}
            workshopLogs={workshopLogs}
            onUpdateOrderNotes={handleUpdateOrderNotes}
            onNavigateToCatalog={() => setActiveView('home')}
          />
        )}

        {activeView === 'admin-dashboard' && (
          <AdminDashboardView
            orders={orders}
            catalog={catalog}
            workshopLogs={workshopLogs}
            onUpdateOrderStatus={handleUpdateOrderStatus}
            onUpdatePaymentStatus={handleUpdatePaymentStatus}
            onAdjustStock={handleAdjustStock}
            onAddFurnitureRecord={handleAddFurnitureRecord}
            onAddWorkshopLog={handleAddWorkshopLog}
          />
        )}

        {activeView === 'login' && (
          <LoginPageView
            currentRole={currentRole}
            currentUserName={currentUserName}
            onLoginSuccess={handleLoginSuccess}
          />
        )}
      </main>

      {/* CATEGORY & FURNITURE SPECIFICATION MODAL */}
      {isDetailModalOpen && (
        <CategoryDetailModal
          category={modalCategory}
          categoryItems={modalCategoryItems}
          initialSelectedItem={modalInitialItem}
          onClose={() => setIsDetailModalOpen(false)}
          onAddToOrder={handleAddToOrder}
        />
      )}

      {/* ORDER INQUIRY & COMMISSION DRAWER */}
      <OrderDrawerModal
        isOpen={isOrderDrawerOpen}
        cartItems={cartItems}
        defaultClientName={currentUserName}
        defaultClientEmail={currentUserEmail}
        onClose={() => setIsOrderDrawerOpen(false)}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onSubmitOrder={handleSubmitOrder}
        onViewOrderInDashboard={() => {
          setIsOrderDrawerOpen(false);
          setActiveView('user-dashboard');
        }}
      />

      {/* SLEEK OBSIDIAN FLAGSHIP FOOTER (#0D1015 + #0095FF + #BCE3FF) */}
      <footer className="surface-obsidian text-slate-300 border-t border-[#0095FF]/40 mt-auto">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 py-14 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 text-xs">
          <div className="space-y-3">
            <div className="flex items-center gap-2.5">
              <span
                aria-hidden="true"
                className="w-7 h-7 rounded-md bg-[#0095FF] flex items-center justify-center text-white font-display font-bold text-sm"
              >
                LR
              </span>
              <span className="font-display text-2xl font-bold text-white tracking-tight">
                Lillia &amp; Rowena
              </span>
            </div>
            <p className="text-slate-400 leading-relaxed">
              2240 Chino Roces Avenue Extension, Makati Flagship Showroom · Cebu Custom Millwork Foundry
            </p>
            <p className="text-[#BCE3FF] font-medium pt-1">
              0% APR 24-Mo Financing · 15-Year Joinery Guarantee
            </p>
          </div>

          <div className="space-y-2.5">
            <p className="font-semibold text-[#BCE3FF] uppercase tracking-wider">Shop by Room</p>
            <ul className="space-y-2 text-slate-300">
              {FURNITURE_CATEGORIES.map((cat) => (
                <li key={cat.id}>
                  <button
                    type="button"
                    onClick={() => handleTopBarCategoryClick(cat)}
                    className="hover:text-[#0095FF] transition-colors cursor-pointer"
                  >
                    {cat.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div className="space-y-2.5">
            <p className="font-semibold text-[#BCE3FF] uppercase tracking-wider">Client Services &amp; Orders</p>
            <ul className="space-y-2 text-slate-300">
              <li>
                <button
                  type="button"
                  onClick={() => setActiveView('user-dashboard')}
                  className="hover:text-[#0095FF] transition-colors cursor-pointer"
                >
                  Track Order &amp; Client Dashboard
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => setIsOrderDrawerOpen(true)}
                  className="hover:text-[#0095FF] transition-colors cursor-pointer"
                >
                  View Shopping Cart &amp; Commission Quote
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => setActiveView('login')}
                  className="hover:text-[#0095FF] transition-colors cursor-pointer"
                >
                  Client &amp; Architect Account Sign In
                </button>
              </li>
            </ul>
          </div>

          <div className="space-y-2.5">
            <p className="font-semibold text-[#BCE3FF] uppercase tracking-wider">Atelier Administration</p>
            <ul className="space-y-2 text-slate-300">
              <li>
                <button
                  type="button"
                  onClick={() => setActiveView('admin-dashboard')}
                  className="hover:text-[#0095FF] transition-colors cursor-pointer"
                >
                  Admin Order &amp; Inventory Console
                </button>
              </li>
              <li className="text-slate-400 pt-1">
                Showroom Hours: Mon–Sun 10:00 AM – 8:00 PM
              </li>
              <li className="text-[#0095FF] font-mono tabular-nums font-medium">
                Concierge: +63 (02) 8842-9100
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 bg-black/40">
          <div className="max-w-7xl mx-auto px-6 lg:px-8 py-4 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
            <p>© 2026 Lillia and Rowena Furniture. All rights reserved.</p>
            <div className="flex flex-wrap items-center gap-6">
              <button
                type="button"
                onClick={() => setActiveView('home')}
                className="hover:text-[#BCE3FF] transition-colors cursor-pointer"
              >
                Storefront Home
              </button>
              <button
                type="button"
                onClick={() => setActiveView('user-dashboard')}
                className="hover:text-[#BCE3FF] transition-colors cursor-pointer"
              >
                User Dashboard
              </button>
              <button
                type="button"
                onClick={() => setActiveView('admin-dashboard')}
                className="hover:text-[#BCE3FF] transition-colors cursor-pointer"
              >
                Admin Dashboard
              </button>
              <button
                type="button"
                onClick={() => setActiveView('login')}
                className="hover:text-[#BCE3FF] transition-colors cursor-pointer"
              >
                Portal Login
              </button>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
