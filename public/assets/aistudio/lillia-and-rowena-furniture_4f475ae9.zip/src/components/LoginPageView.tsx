import React, { useState } from 'react';
import { Lock, ArrowRight, KeyRound, ShieldCheck } from 'lucide-react';
import {
  FURNITURE_CATEGORIES,
  validateLoginCredentials,
} from '../utils/furnitureStore';
import { ResilientImage } from './ResilientImage';

interface LoginPageViewProps {
  currentRole: 'client' | 'admin';
  currentUserName: string;
  onLoginSuccess: (role: 'client' | 'admin', displayName: string, email: string) => void;
}

export const LoginPageView: React.FC<LoginPageViewProps> = ({
  currentRole,
  currentUserName,
  onLoginSuccess,
}) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    const result = validateLoginCredentials(email, password);
    if (!result.valid || !result.role || !result.displayName) {
      setErrorMessage(result.error || 'Invalid credentials.');
      return;
    }

    onLoginSuccess(result.role, result.displayName, email.trim());
  };

  const fillClientDemo = () => {
    setEmail('rowena.vance@vancearchitects.com');
    setPassword('client2026');
    setErrorMessage('');
  };

  const fillAdminDemo = () => {
    setEmail('lillia@lilliarowena.com');
    setPassword('atelier2026');
    setErrorMessage('');
  };

  const loginEditorialImage =
    FURNITURE_CATEGORIES.find((c) => c.id === 'office')?.imageUrl ||
    FURNITURE_CATEGORIES[0].imageUrl;

  return (
    <div className="max-w-6xl mx-auto px-6 lg:px-8 py-12">
      <div className="rounded-3xl bg-white border border-[#BCE3FF] shadow-xl grid grid-cols-1 lg:grid-cols-12 overflow-hidden">
        {/* Left Column: Editorial Showroom Context */}
        <div className="lg:col-span-6 relative min-h-[380px] bg-[#0D1015] flex flex-col justify-end">
          <ResilientImage
            src={loginEditorialImage}
            alt="Lillia and Rowena Furniture Atelier Study & Credenza Collection"
            className="absolute inset-0 w-full h-full object-cover"
          />
          <div className="relative z-10 p-8 sm:p-10 pt-28 bg-gradient-to-t from-[#0D1015]/95 via-[#0D1015]/75 to-transparent flex flex-col justify-end text-white space-y-4">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-[#BCE3FF]">
                Lillia &amp; Rowena Furniture · Record Portal Access
              </p>
              <h1 className="font-display text-3xl sm:text-4xl font-bold text-white mt-1.5">
                Bespoke Order &amp; Atelier Record Management.
              </h1>
            </div>

            <div className="space-y-3">
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                Clients and interior architects can track live millwork milestones, inspect timber moisture logs, and manage white-glove delivery instructions. Atelier administrators can update production statuses and catalog inventory.
              </p>
              <div className="pt-3 border-t border-white/15 text-xs text-[#BCE3FF] flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 shrink-0 text-[#0095FF]" />
                <span>
                  Active session: {currentUserName} ({currentRole === 'admin' ? 'Atelier Admin' : 'Client Portal'})
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Validated Sign-In Form & Role Presets */}
        <div className="lg:col-span-6 flex flex-col justify-between p-8 sm:p-10 space-y-6">
          <div className="space-y-6">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-[#0095FF]">
                Account Authentication
              </p>
              <h2 className="font-display text-3xl sm:text-4xl font-bold text-[#0D1015] mt-1">
                Sign In to Your Portal
              </h2>
            </div>

            {/* Quick-Fill Demo Role Buttons for Seamless Evaluation */}
            <div className="rounded-2xl bg-[#F4FAFF] border border-[#BCE3FF] p-4 space-y-2.5">
              <p className="text-xs font-semibold text-[#0D1015] flex items-center gap-1.5">
                <KeyRound className="w-3.5 h-3.5 text-[#0095FF]" /> Quick-Fill Portal Credentials
              </p>
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={fillClientDemo}
                  className="px-3.5 py-2 text-xs font-semibold rounded-xl bg-white border border-[#BCE3FF] text-[#0D1015] hover:bg-[#0095FF] hover:text-white hover:border-[#0095FF] transition-colors cursor-pointer whitespace-nowrap shrink-0"
                >
                  Fill Client Portal (Rowena Vance)
                </button>
                <button
                  type="button"
                  onClick={fillAdminDemo}
                  className="px-3.5 py-2 text-xs font-semibold rounded-xl bg-white border border-[#BCE3FF] text-[#0D1015] hover:bg-[#0095FF] hover:text-white hover:border-[#0095FF] transition-colors cursor-pointer whitespace-nowrap shrink-0"
                >
                  Fill Admin Console (Lillia Mercier)
                </button>
              </div>
            </div>

            <form onSubmit={handleFormSubmit} className="space-y-4" noValidate>
              {errorMessage && (
                <div
                  role="alert"
                  className="p-3 text-xs text-red-700 bg-red-50 border border-red-200 rounded-xl"
                >
                  {errorMessage}
                </div>
              )}

              <div>
                <label
                  htmlFor="login-email-input"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  Registered Email Address
                </label>
                <input
                  id="login-email-input"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="rowena.vance@vancearchitects.com"
                  className="w-full px-3.5 py-2.5 text-sm bg-[#F4FAFF] border border-[#BCE3FF] rounded-xl text-[#0D1015] focus:outline-none focus:bg-white focus:border-[#0095FF]"
                />
              </div>

              <div>
                <label
                  htmlFor="login-password-input"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  Portal Password
                </label>
                <input
                  id="login-password-input"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  className="w-full px-3.5 py-2.5 text-sm bg-[#F4FAFF] border border-[#BCE3FF] rounded-xl text-[#0D1015] focus:outline-none focus:bg-white focus:border-[#0095FF]"
                />
              </div>

              <button
                type="submit"
                className="w-full flex items-center justify-center gap-2 py-3 px-5 text-xs sm:text-sm font-semibold text-white bg-[#0095FF] hover:bg-[#007ACC] rounded-xl shadow-xs transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                <Lock className="w-4 h-4" />
                <span>Sign In &amp; Open Dashboard</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          </div>

          <div className="pt-4 border-t border-[#BCE3FF] text-xs text-slate-600 space-y-1">
            <p>
              Client emails route to the Client Order &amp; Specification Portal.
            </p>
            <p>
              Atelier emails (<span className="font-mono font-semibold text-[#0095FF]">lillia@lilliarowena.com</span>) route to the Admin Record Management Console.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
