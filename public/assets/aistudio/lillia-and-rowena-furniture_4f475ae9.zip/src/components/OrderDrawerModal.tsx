import React, { useState, useEffect } from 'react';
import { X, Trash2, CheckCircle2, ArrowRight } from 'lucide-react';
import {
  FurnitureItem,
  calculateOrderPricing,
} from '../utils/furnitureStore';

export interface CartLineItem {
  furniture: FurnitureItem;
  finish: string;
  quantity: number;
}

interface OrderDrawerModalProps {
  isOpen: boolean;
  cartItems: CartLineItem[];
  defaultClientName: string;
  defaultClientEmail: string;
  onClose: () => void;
  onUpdateQuantity: (furnitureId: string, finish: string, delta: number) => void;
  onRemoveItem: (furnitureId: string, finish: string) => void;
  onSubmitOrder: (orderPayload: {
    clientName: string;
    clientEmail: string;
    clientPhone: string;
    shippingAddress: string;
    notes: string;
  }) => string;
  onViewOrderInDashboard: () => void;
}

export const OrderDrawerModal: React.FC<OrderDrawerModalProps> = ({
  isOpen,
  cartItems,
  defaultClientName,
  defaultClientEmail,
  onClose,
  onUpdateQuantity,
  onRemoveItem,
  onSubmitOrder,
  onViewOrderInDashboard,
}) => {
  const [clientName, setClientName] = useState(defaultClientName || 'Rowena Vance');
  const [clientEmail, setClientEmail] = useState(
    defaultClientEmail || 'rowena.vance@vancearchitects.com'
  );
  const [clientPhone, setClientPhone] = useState('+63 917 482 9104');
  const [shippingAddress, setShippingAddress] = useState(
    'Unit 14B, One Rockwell East Tower, Makati City'
  );
  const [notes, setNotes] = useState(
    'Please coordinate Saturday morning freight elevator access with building concierge.'
  );
  const [formError, setFormError] = useState('');
  const [confirmedOrderId, setConfirmedOrderId] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setConfirmedOrderId(null);
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const pricing = calculateOrderPricing(
    cartItems.map((line) => ({
      unitPrice: line.furniture.price,
      quantity: line.quantity,
    }))
  );

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (cartItems.length === 0) {
      setFormError('Your order inquiry list is currently empty.');
      return;
    }
    if (!clientName.trim() || !clientEmail.trim() || !shippingAddress.trim()) {
      setFormError('Please provide your full name, email address, and delivery address.');
      return;
    }

    const newId = onSubmitOrder({
      clientName: clientName.trim(),
      clientEmail: clientEmail.trim(),
      clientPhone: clientPhone.trim() || '+63 917 000 0000',
      shippingAddress: shippingAddress.trim(),
      notes: notes.trim(),
    });
    setConfirmedOrderId(newId);
  };

  return (
    <div
      onClick={() => {
        setConfirmedOrderId(null);
        onClose();
      }}
      className="fixed inset-0 z-50 flex justify-end bg-[#0D1015]/70 backdrop-blur-xs"
      role="dialog"
      aria-modal="true"
      aria-labelledby="order-drawer-title"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-xl bg-[#F8FBFF] h-full shadow-2xl border-l border-[#BCE3FF] flex flex-col justify-between overflow-hidden"
      >
        {/* Drawer Header */}
        <div className="flex items-center justify-between px-6 py-5 surface-obsidian text-white border-b border-[#0095FF]/40 shrink-0">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-[#BCE3FF]">
              Bespoke Commission &amp; White-Glove Dispatch
            </p>
            <h2
              id="order-drawer-title"
              className="font-display text-2xl font-bold text-white mt-0.5"
            >
              Shopping Cart &amp; Commission Ledger
            </h2>
          </div>
          <button
            type="button"
            onClick={() => {
              setConfirmedOrderId(null);
              onClose();
            }}
            aria-label="Close order inquiry drawer"
            className="p-2 rounded-lg text-slate-300 hover:text-white hover:bg-[#0095FF] bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Drawer Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {confirmedOrderId ? (
            <div className="rounded-2xl bg-white border border-[#BCE3FF] p-8 space-y-5 text-center shadow-xs">
              <CheckCircle2 className="w-10 h-10 text-[#0095FF] mx-auto stroke-[1.5]" />
              <div className="space-y-2">
                <p className="text-xs font-mono font-bold text-[#0095FF] tabular-nums">
                  COMMISSION RECORD #{confirmedOrderId}
                </p>
                <h3 className="font-display text-2xl font-bold text-[#0D1015]">
                  Order Confirmed &amp; Logged in Atelier Records
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Your commission has been assigned to our millwork queue and synced with both your Client Portal and the Admin Record Console.
                </p>
              </div>
              <div className="pt-4 flex flex-col sm:flex-row gap-3 justify-center">
                <button
                  type="button"
                  onClick={() => {
                    setConfirmedOrderId(null);
                    onViewOrderInDashboard();
                  }}
                  className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-xs font-semibold text-white bg-[#0095FF] hover:bg-[#007ACC] rounded-xl transition-colors cursor-pointer whitespace-nowrap shrink-0"
                >
                  <span>Track in Client Dashboard</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setConfirmedOrderId(null);
                    onClose();
                  }}
                  className="px-5 py-2.5 text-xs font-semibold text-[#0D1015] bg-[#BCE3FF] hover:bg-[#BCE3FF]/70 rounded-xl transition-colors cursor-pointer whitespace-nowrap shrink-0"
                >
                  Continue Browsing Showroom
                </button>
              </div>
            </div>
          ) : cartItems.length === 0 ? (
            <div className="bg-white border border-slate-200 rounded-lg p-10 text-center space-y-3">
              <p className="font-display text-2xl font-bold text-slate-900">
                No Furniture Pieces Selected
              </p>
              <p className="text-xs text-slate-500 max-w-xs mx-auto leading-relaxed">
                Explore the Product Category Grid or Search Catalog to select timber finishes and add pieces to your order inquiry.
              </p>
            </div>
          ) : (
            <>
              {/* Itemized List */}
              <div className="space-y-3">
                <p className="text-xs font-semibold text-slate-700">
                  Selected Pieces ({cartItems.reduce((s, i) => s + i.quantity, 0)})
                </p>
                {cartItems.map((line) => (
                  <div
                    key={`${line.furniture.id}-${line.finish}`}
                    className="bg-white border border-slate-200 rounded-lg p-4 flex items-start justify-between gap-4"
                  >
                    <div className="space-y-1">
                      <p className="text-sm font-bold text-slate-900">
                        {line.furniture.name}
                      </p>
                      <p className="text-xs text-slate-500">
                        Finish: {line.finish} · <span className="font-mono tabular-nums text-sky-700">{line.furniture.sku}</span>
                      </p>
                      <p className="font-mono text-xs font-semibold text-slate-800 tabular-nums pt-1">
                        ${line.furniture.price.toLocaleString()} each
                      </p>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() =>
                          onUpdateQuantity(line.furniture.id, line.finish, -1)
                        }
                        aria-label={`Decrease quantity of ${line.furniture.name}`}
                        className="w-7 h-7 flex items-center justify-center bg-sky-50 border border-sky-200 rounded-sm text-sky-900 hover:bg-sky-100 text-xs font-mono cursor-pointer"
                      >
                        -
                      </button>
                      <span className="w-6 text-center font-mono text-xs font-semibold tabular-nums">
                        {line.quantity}
                      </span>
                      <button
                        type="button"
                        onClick={() =>
                          onUpdateQuantity(line.furniture.id, line.finish, 1)
                        }
                        aria-label={`Increase quantity of ${line.furniture.name}`}
                        className="w-7 h-7 flex items-center justify-center bg-sky-50 border border-sky-200 rounded-sm text-sky-900 hover:bg-sky-100 text-xs font-mono cursor-pointer"
                      >
                        +
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          onRemoveItem(line.furniture.id, line.finish)
                        }
                        aria-label={`Remove ${line.furniture.name} from order`}
                        className="p-1.5 text-slate-400 hover:text-red-600 transition-colors cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Financial Summary */}
              <div className="bg-blue-50/80 border border-blue-200 rounded-lg p-4 space-y-2 text-xs">
                <div className="flex justify-between text-slate-600">
                  <span>Pieces Subtotal</span>
                  <span className="font-mono tabular-nums">
                    ${pricing.subtotal.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>White-Glove Placement &amp; Assembly</span>
                  <span className="font-mono tabular-nums text-amber-700 font-semibold">
                    {pricing.whiteGloveFee === 0
                      ? 'Complimentary ($3,000+)'
                      : `$${pricing.whiteGloveFee}`}
                  </span>
                </div>
                <div className="flex justify-between text-sm font-bold text-slate-900 pt-2 border-t border-blue-200">
                  <span>Total Commission Amount</span>
                  <span className="font-mono tabular-nums">
                    ${pricing.totalAmount.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between text-slate-600 pt-1">
                  <span>50% Millwork Initiation Deposit (or 0% APR 24-Mo Financing)</span>
                  <span className="font-mono tabular-nums font-semibold text-blue-700">
                    ${pricing.depositRequired.toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Client Registration & Delivery Verification Form */}
              <form id="commission-order-form" onSubmit={handlePlaceOrder} className="space-y-4">
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Client Record &amp; White-Glove Delivery Details
                </h3>

                {formError && (
                  <p className="text-xs text-red-700 bg-red-50 border border-red-200 rounded-md p-3">
                    {formError}
                  </p>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label
                      htmlFor="order-client-name"
                      className="block text-xs font-medium text-slate-700 mb-1"
                    >
                      Client or Architect Name
                    </label>
                    <input
                      id="order-client-name"
                      type="text"
                      value={clientName}
                      onChange={(e) => setClientName(e.target.value)}
                      className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-md text-slate-900 focus:outline-none focus:border-blue-600"
                    />
                  </div>
                  <div>
                    <label
                      htmlFor="order-client-email"
                      className="block text-xs font-medium text-slate-700 mb-1"
                    >
                      Email for Record Tracking
                    </label>
                    <input
                      id="order-client-email"
                      type="email"
                      value={clientEmail}
                      onChange={(e) => setClientEmail(e.target.value)}
                      className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-md text-slate-900 focus:outline-none focus:border-blue-600"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label
                      htmlFor="order-client-phone"
                      className="block text-xs font-medium text-slate-700 mb-1"
                    >
                      Contact Number
                    </label>
                    <input
                      id="order-client-phone"
                      type="text"
                      value={clientPhone}
                      onChange={(e) => setClientPhone(e.target.value)}
                      className="w-full px-3 py-2 text-xs font-mono bg-white border border-slate-300 rounded-md text-slate-900 focus:outline-none focus:border-blue-600"
                    />
                  </div>
                  <div>
                    <label
                      htmlFor="order-shipping-address"
                      className="block text-xs font-medium text-slate-700 mb-1"
                    >
                      Delivery Site Address
                    </label>
                    <input
                      id="order-shipping-address"
                      type="text"
                      value={shippingAddress}
                      onChange={(e) => setShippingAddress(e.target.value)}
                      className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-md text-slate-900 focus:outline-none focus:border-blue-600"
                    />
                  </div>
                </div>

                <div>
                  <label
                    htmlFor="order-architectural-notes"
                    className="block text-xs font-medium text-slate-700 mb-1"
                  >
                    Architectural Site &amp; Finish Notes
                  </label>
                  <textarea
                    id="order-architectural-notes"
                    rows={2}
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-md text-slate-900 focus:outline-none focus:border-blue-600"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 px-5 text-xs sm:text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-md shadow-xs transition-colors cursor-pointer whitespace-nowrap shrink-0"
                >
                  Confirm Commission Order · ${pricing.totalAmount.toLocaleString()}
                </button>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
