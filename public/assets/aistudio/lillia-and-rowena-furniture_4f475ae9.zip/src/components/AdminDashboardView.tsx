import React, { useState } from 'react';
import {
  Search,
  Plus,
  ClipboardList,
  Package,
  Hammer,
  CheckCircle2,
  AlertTriangle,
  X,
} from 'lucide-react';
import {
  CategoryId,
  FurnitureItem,
  OrderRecord,
  OrderStatus,
  PaymentStatus,
  WorkshopLogEntry,
  ORDER_STATUS_STEPS,
  FURNITURE_CATEGORIES,
  computeDashboardMetrics,
  validateNewFurnitureInput,
} from '../utils/furnitureStore';

interface AdminDashboardViewProps {
  orders: OrderRecord[];
  catalog: FurnitureItem[];
  workshopLogs: WorkshopLogEntry[];
  onUpdateOrderStatus: (orderId: string, newStatus: OrderStatus) => void;
  onUpdatePaymentStatus: (orderId: string, newPayment: PaymentStatus) => void;
  onAdjustStock: (furnitureId: string, delta: number) => void;
  onAddFurnitureRecord: (newItem: FurnitureItem) => void;
  onAddWorkshopLog: (newLog: Omit<WorkshopLogEntry, 'id' | 'timestamp'>) => void;
}

export const AdminDashboardView: React.FC<AdminDashboardViewProps> = ({
  orders,
  catalog,
  workshopLogs,
  onUpdateOrderStatus,
  onUpdatePaymentStatus,
  onAdjustStock,
  onAddFurnitureRecord,
  onAddWorkshopLog,
}) => {
  const [activeTab, setActiveTab] = useState<'orders' | 'inventory' | 'logs'>('orders');
  const [orderSearch, setOrderSearch] = useState('');
  const [orderStatusFilter, setOrderStatusFilter] = useState<OrderStatus | 'all'>('all');
  const [inventorySearch, setInventorySearch] = useState('');

  // Modal state for adding new furniture catalog record
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newName, setNewName] = useState('');
  const [newSku, setNewSku] = useState('');
  const [newCategory, setNewCategory] = useState<CategoryId>('living');
  const [newPrice, setNewPrice] = useState('2850');
  const [newDimensions, setNewDimensions] = useState('180cm W × 90cm D × 75cm H');
  const [newFinish, setNewFinish] = useState('Hand-Rubbed Natural Walnut');
  const [newStock, setNewStock] = useState('4');
  const [newLeadWeeks, setNewLeadWeeks] = useState('4');
  const [newDescription, setNewDescription] = useState(
    'Bespoke architectural piece milled from FAS-grade kiln-dried hardwood with traditional mortise-and-tenon joinery.'
  );
  const [addFormError, setAddFormError] = useState('');

  // New workshop log state
  const [logOrderId, setLogOrderId] = useState(orders[0]?.id || 'ORD-2026-841');
  const [logStation, setLogStation] = useState('Joinery & Millwork Bench 01');
  const [logArtisan, setLogArtisan] = useState('Mateo Reyes');
  const [logNote, setLogNote] = useState('');
  const [logFeedback, setLogFeedback] = useState('');

  const metrics = computeDashboardMetrics(orders, catalog);

  const filteredOrders = orders.filter((ord) => {
    const matchesStatus =
      orderStatusFilter === 'all' || ord.status === orderStatusFilter;
    if (!matchesStatus) return false;
    if (!orderSearch.trim()) return true;
    const q = orderSearch.trim().toLowerCase();
    return (
      ord.id.toLowerCase().includes(q) ||
      ord.clientName.toLowerCase().includes(q) ||
      ord.clientEmail.toLowerCase().includes(q) ||
      ord.craftspersonAssigned.toLowerCase().includes(q) ||
      ord.items.some((i) => i.name.toLowerCase().includes(q) || i.sku.toLowerCase().includes(q))
    );
  });

  const filteredCatalog = catalog.filter((item) => {
    if (!inventorySearch.trim()) return true;
    const q = inventorySearch.trim().toLowerCase();
    return (
      item.name.toLowerCase().includes(q) ||
      item.sku.toLowerCase().includes(q) ||
      item.categoryName.toLowerCase().includes(q) ||
      item.defaultFinish.toLowerCase().includes(q)
    );
  });

  const handleCreateFurnitureRecord = (e: React.FormEvent) => {
    e.preventDefault();
    setAddFormError('');

    const parsedPrice = Number(newPrice);
    const parsedStock = Number(newStock);
    const parsedWeeks = Number(newLeadWeeks) || 4;

    const validation = validateNewFurnitureInput({
      name: newName,
      sku: newSku,
      categoryId: newCategory,
      price: parsedPrice,
      dimensions: newDimensions,
      defaultFinish: newFinish,
      stockCount: parsedStock,
    });

    if (!validation.valid) {
      setAddFormError(validation.error || 'Please check all required fields.');
      return;
    }

    const catObj =
      FURNITURE_CATEGORIES.find((c) => c.id === newCategory) ||
      FURNITURE_CATEGORIES[0];

    const createdItem: FurnitureItem = {
      id: `furn-${Date.now()}`,
      sku: newSku.trim().toUpperCase(),
      name: newName.trim(),
      categoryId: newCategory,
      categoryName: catObj.name,
      price: parsedPrice,
      dimensions: newDimensions.trim(),
      materials: [newFinish.trim(), 'FSC-Certified Solid Timber'],
      defaultFinish: newFinish.trim(),
      availableFinishes: [newFinish.trim(), 'Natural White Oak', 'Oiled Black Walnut'],
      stockCount: parsedStock,
      leadTimeWeeks: parsedWeeks,
      weightKg: 65,
      description: newDescription.trim(),
      craftsmanshipDetails: [
        'Registered via Lillia & Rowena Admin Atelier Console',
        'Mortise-and-tenon solid hardwood joinery verified to 8.2% moisture equilibrium',
      ],
      imageUrl: catObj.imageUrl,
      featured: false,
    };

    onAddFurnitureRecord(createdItem);
    setNewName('');
    setNewSku('');
    setIsAddModalOpen(false);
    setActiveTab('inventory');
  };

  const handleCreateWorkshopLog = (e: React.FormEvent) => {
    e.preventDefault();
    if (!logNote.trim()) return;
    onAddWorkshopLog({
      orderId: logOrderId,
      benchStation: logStation,
      artisan: logArtisan,
      note: logNote.trim(),
    });
    setLogNote('');
    setLogFeedback(`Logged QC entry for ${logOrderId}`);
    setTimeout(() => setLogFeedback(''), 3000);
  };

  return (
    <div className="max-w-7xl mx-auto px-6 lg:px-8 py-10 space-y-8">
      {/* Top Breadcrumb & Primary Action Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-[#BCE3FF] pb-6">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-[#0095FF]">
            Atelier Administration · Order Ledger, Catalog Inventory &amp; Millwork QC
          </p>
          <h1 className="font-display text-3xl sm:text-4xl font-bold text-[#0D1015] mt-1">
            Admin Order &amp; Record Management Console
          </h1>
        </div>

        <div className="flex items-center gap-3 self-start md:self-auto">
          <button
            type="button"
            onClick={() => setIsAddModalOpen(true)}
            className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-white bg-[#0095FF] hover:bg-[#007ACC] rounded-xl shadow-2xs transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Furniture Record</span>
          </button>
        </div>
      </div>

      {/* 4-Column Executive KPI Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 rounded-2xl bg-white border border-[#BCE3FF] shadow-xs p-6">
        <div className="border-r border-[#BCE3FF]/60 pr-4">
          <p className="text-xs font-medium text-slate-500">Total Commission Volume</p>
          <p className="font-mono text-2xl font-bold text-[#0D1015] mt-1 tabular-nums">
            ${metrics.totalRevenue.toLocaleString()}
          </p>
          <p className="text-xs text-slate-500 mt-0.5 font-mono tabular-nums">
            Across {orders.length} active &amp; archived orders
          </p>
        </div>
        <div className="lg:border-r border-[#BCE3FF]/60 lg:pr-4">
          <p className="text-xs font-medium text-slate-500">Active Millwork Queue</p>
          <p className="font-mono text-2xl font-bold text-[#0095FF] mt-1 tabular-nums">
            {metrics.activeProductionCount} Orders
          </p>
          <p className="text-xs text-slate-500 mt-0.5 font-mono tabular-nums">
            {metrics.completedCount} completed white-glove dispatches
          </p>
        </div>
        <div className="border-r border-[#BCE3FF]/60 pr-4">
          <p className="text-xs font-medium text-slate-500">Catalog SKUs &amp; Units</p>
          <p className="font-mono text-2xl font-bold text-[#0D1015] mt-1 tabular-nums">
            {catalog.length} SKUs · {metrics.totalCatalogStock} Units
          </p>
          <p className="text-xs text-slate-500 mt-0.5">
            Ready for immediate dispatch or custom finish
          </p>
        </div>
        <div>
          <p className="text-xs font-medium text-slate-500">Low-Stock Timber Alert</p>
          <p className="font-mono text-2xl font-bold text-[#0D1015] mt-1 tabular-nums flex items-center gap-2">
            <span>{metrics.lowStockItemCount} Pieces</span>
            {metrics.lowStockItemCount > 0 && (
              <AlertTriangle className="w-4 h-4 text-[#0095FF]" />
            )}
          </p>
          <p className="text-xs text-slate-500 mt-0.5">
            Threshold: ≤ 4 units in showroom archive
          </p>
        </div>
      </div>

      {/* Workspace Section Switcher Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#BCE3FF] pb-4">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setActiveTab('orders')}
            className={`inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-xl border transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
              activeTab === 'orders'
                ? 'bg-[#0095FF] text-white border-[#0095FF] shadow-2xs'
                : 'bg-white text-slate-700 border-[#BCE3FF] hover:bg-[#BCE3FF]/50'
            }`}
          >
            <ClipboardList className="w-3.5 h-3.5" />
            <span>Client Order Records ({orders.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('inventory')}
            className={`inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-xl border transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
              activeTab === 'inventory'
                ? 'bg-[#0095FF] text-white border-[#0095FF] shadow-2xs'
                : 'bg-white text-slate-700 border-[#BCE3FF] hover:bg-[#BCE3FF]/50'
            }`}
          >
            <Package className="w-3.5 h-3.5" />
            <span>Furniture Inventory Records ({catalog.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('logs')}
            className={`inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-xl border transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
              activeTab === 'logs'
                ? 'bg-[#0095FF] text-white border-[#0095FF] shadow-2xs'
                : 'bg-white text-slate-700 border-[#BCE3FF] hover:bg-[#BCE3FF]/50'
            }`}
          >
            <Hammer className="w-3.5 h-3.5" />
            <span>Workshop QC Logbook ({workshopLogs.length})</span>
          </button>
        </div>
      </div>

      {/* TAB 1: CLIENT ORDER RECORDS TABLE */}
      {activeTab === 'orders' && (
        <div className="space-y-4">
          {/* Search & Status Filter Bar */}
          <div className="bg-sky-50/70 border border-sky-200/80 rounded-lg p-4 flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4">
            <div className="relative flex-1 max-w-md">
              <label htmlFor="admin-order-search" className="sr-only">
                Search order records by ID, client name, or SKU
              </label>
              <Search className="w-4 h-4 text-sky-600 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                id="admin-order-search"
                type="search"
                value={orderSearch}
                onChange={(e) => setOrderSearch(e.target.value)}
                placeholder="Search by Order ID, client, joiner, or SKU..."
                className="w-full pl-9 pr-3 py-2 text-xs bg-white border border-slate-300 rounded-md text-slate-900 focus:outline-none focus:border-sky-600"
              />
            </div>

            <div className="flex flex-wrap items-center gap-1.5">
              <button
                type="button"
                onClick={() => setOrderStatusFilter('all')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  orderStatusFilter === 'all'
                    ? 'bg-sky-600 text-white shadow-2xs'
                    : 'bg-white text-slate-700 border border-slate-200 hover:border-sky-400 hover:text-sky-700'
                }`}
              >
                All Stages
              </button>
              {ORDER_STATUS_STEPS.map((st) => (
                <button
                  key={st}
                  type="button"
                  onClick={() => setOrderStatusFilter(st)}
                  className={`px-2.5 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                    orderStatusFilter === st
                      ? 'bg-sky-600 text-white shadow-2xs'
                      : 'bg-white text-slate-700 border border-slate-200 hover:border-sky-400 hover:text-sky-700'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>
          </div>

          {/* High-Density Order Management Data Grid */}
          <div className="bg-white border border-slate-200 rounded-lg overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-bold text-slate-600 uppercase tracking-wider">
                  <th className="py-3 px-4">Order ID &amp; Date</th>
                  <th className="py-3 px-4">Client &amp; Destination</th>
                  <th className="py-3 px-4">Commissioned Pieces</th>
                  <th className="py-3 px-4">Production Stage</th>
                  <th className="py-3 px-4">Payment Record</th>
                  <th className="py-3 px-4 text-right">Total (USD)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-xs">
                {filteredOrders.map((ord) => (
                  <tr key={ord.id} className="hover:bg-sky-50/40 transition-colors">
                    <td className="py-3.5 px-4 align-top whitespace-nowrap">
                      <p className="font-mono font-bold text-sky-700 tabular-nums">
                        {ord.id}
                      </p>
                      <p className="font-mono text-slate-500 tabular-nums mt-0.5">
                        {ord.createdAt}
                      </p>
                      <p className="text-slate-500 mt-0.5">
                        Est: <span className="font-mono tabular-nums">{ord.estimatedDelivery}</span>
                      </p>
                    </td>

                    <td className="py-3.5 px-4 align-top max-w-xs">
                      <p className="font-bold text-slate-900">{ord.clientName}</p>
                      <p className="text-slate-500 truncate">{ord.shippingAddress}</p>
                      <p className="text-slate-500 mt-0.5">
                        Joiner: {ord.craftspersonAssigned}
                      </p>
                    </td>

                    <td className="py-3.5 px-4 align-top">
                      <ul className="space-y-1">
                        {ord.items.map((item, i) => (
                          <li key={i} className="text-slate-800">
                            <span className="font-mono tabular-nums font-semibold text-sky-700">
                              {item.quantity}×
                            </span>{' '}
                            {item.name}{' '}
                            <span className="text-slate-500">({item.finish})</span>
                          </li>
                        ))}
                      </ul>
                    </td>

                    <td className="py-3.5 px-4 align-top">
                      <label htmlFor={`status-select-${ord.id}`} className="sr-only">
                        Update status for order {ord.id}
                      </label>
                      <select
                        id={`status-select-${ord.id}`}
                        value={ord.status}
                        onChange={(e) =>
                          onUpdateOrderStatus(ord.id, e.target.value as OrderStatus)
                        }
                        className="px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-300 rounded-md text-slate-900 font-medium focus:outline-none focus:border-sky-600"
                      >
                        {ORDER_STATUS_STEPS.map((st) => (
                          <option key={st} value={st}>
                            {st}
                          </option>
                        ))}
                      </select>
                    </td>

                    <td className="py-3.5 px-4 align-top">
                      <label htmlFor={`payment-select-${ord.id}`} className="sr-only">
                        Update payment record for order {ord.id}
                      </label>
                      <select
                        id={`payment-select-${ord.id}`}
                        value={ord.paymentStatus}
                        onChange={(e) =>
                          onUpdatePaymentStatus(ord.id, e.target.value as PaymentStatus)
                        }
                        className="px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-300 rounded-md text-slate-900 focus:outline-none focus:border-sky-600"
                      >
                        <option value="Deposit Paid (50%)">Deposit Paid (50%)</option>
                        <option value="Paid in Full">Paid in Full</option>
                        <option value="Invoice Pending">Invoice Pending</option>
                      </select>
                    </td>

                    <td className="py-3.5 px-4 align-top text-right font-mono font-bold text-slate-900 tabular-nums">
                      ${ord.totalAmount.toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: FURNITURE INVENTORY & CATALOG RECORDS */}
      {activeTab === 'inventory' && (
        <div className="space-y-4">
          <div className="bg-sky-50/70 border border-sky-200/80 rounded-lg p-4 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
            <div className="relative flex-1 max-w-md">
              <label htmlFor="admin-inventory-search" className="sr-only">
                Search furniture catalog records
              </label>
              <Search className="w-4 h-4 text-sky-600 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                id="admin-inventory-search"
                type="search"
                value={inventorySearch}
                onChange={(e) => setInventorySearch(e.target.value)}
                placeholder="Search SKU, piece name, category, or finish..."
                className="w-full pl-9 pr-3 py-2 text-xs bg-white border border-slate-300 rounded-md text-slate-900 focus:outline-none focus:border-sky-600"
              />
            </div>

            <button
              type="button"
              onClick={() => setIsAddModalOpen(true)}
              className="inline-flex items-center justify-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-sky-600 hover:bg-sky-500 rounded-md transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Register New Catalog SKU</span>
            </button>
          </div>

          <div className="bg-white border border-slate-200 rounded-lg overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-bold text-slate-600 uppercase tracking-wider">
                  <th className="py-3 px-4">SKU</th>
                  <th className="py-3 px-4">Piece Name &amp; Category</th>
                  <th className="py-3 px-4">Dimensions</th>
                  <th className="py-3 px-4">Standard Finish</th>
                  <th className="py-3 px-4 text-right">Lead Time</th>
                  <th className="py-3 px-4 text-right">Unit Price</th>
                  <th className="py-3 px-4 text-right">Showroom Stock</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-xs">
                {filteredCatalog.map((item) => (
                  <tr key={item.id} className="hover:bg-sky-50/40 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-sky-700 tabular-nums whitespace-nowrap">
                      {item.sku}
                    </td>
                    <td className="py-3 px-4">
                      <p className="font-bold text-slate-900">{item.name}</p>
                      <p className="text-slate-500">{item.categoryName}</p>
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-600 tabular-nums">
                      {item.dimensions}
                    </td>
                    <td className="py-3 px-4 text-slate-700">{item.defaultFinish}</td>
                    <td className="py-3 px-4 text-right font-mono text-slate-700 tabular-nums">
                      {item.leadTimeWeeks} wks
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 tabular-nums">
                      ${item.price.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="inline-flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => onAdjustStock(item.id, -1)}
                          aria-label={`Decrease stock for ${item.name}`}
                          className="w-6 h-6 flex items-center justify-center bg-sky-50 border border-sky-200 rounded-sm text-sky-900 hover:bg-sky-100 font-mono cursor-pointer"
                        >
                          -
                        </button>
                        <span
                          className={`w-8 text-center font-mono font-bold tabular-nums ${
                            item.stockCount <= 4 ? 'text-amber-600' : 'text-slate-900'
                          }`}
                        >
                          {item.stockCount}
                        </span>
                        <button
                          type="button"
                          onClick={() => onAdjustStock(item.id, 1)}
                          aria-label={`Increase stock for ${item.name}`}
                          className="w-6 h-6 flex items-center justify-center bg-sky-50 border border-sky-200 rounded-sm text-sky-900 hover:bg-sky-100 font-mono cursor-pointer"
                        >
                          +
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: MILLWORK & QC LOGBOOK */}
      {activeTab === 'logs' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left: Append New Inspection Log Form */}
          <form
            onSubmit={handleCreateWorkshopLog}
            className="lg:col-span-5 bg-white border border-slate-200 rounded-lg p-6 space-y-4"
          >
            <h2 className="font-display text-2xl font-bold text-slate-900">
              Record Bench Inspection Entry
            </h2>
            <p className="text-xs text-slate-500">
              Log timber moisture readings, joinery tolerances, or finishing coats directly to an active commission record.
            </p>

            {logFeedback && (
              <p className="text-xs text-sky-800 bg-sky-50 border border-sky-200 rounded-md p-3 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-sky-600" />
                <span>{logFeedback}</span>
              </p>
            )}

            <div>
              <label
                htmlFor="log-order-select"
                className="block text-xs font-semibold text-slate-700 mb-1"
              >
                Target Commission Order ID
              </label>
              <select
                id="log-order-select"
                value={logOrderId}
                onChange={(e) => setLogOrderId(e.target.value)}
                className="w-full px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-300 rounded-md text-slate-900 focus:outline-none focus:border-sky-600"
              >
                {orders.map((o) => (
                  <option key={o.id} value={o.id}>
                    {o.id} — {o.clientName} ({o.status})
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label
                  htmlFor="log-bench-station"
                  className="block text-xs font-semibold text-slate-700 mb-1"
                >
                  Workshop Bench Station
                </label>
                <input
                  id="log-bench-station"
                  type="text"
                  value={logStation}
                  onChange={(e) => setLogStation(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md text-slate-900 focus:outline-none focus:border-sky-600"
                />
              </div>
              <div>
                <label
                  htmlFor="log-artisan-name"
                  className="block text-xs font-semibold text-slate-700 mb-1"
                >
                  Inspecting Artisan
                </label>
                <input
                  id="log-artisan-name"
                  type="text"
                  value={logArtisan}
                  onChange={(e) => setLogArtisan(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md text-slate-900 focus:outline-none focus:border-sky-600"
                />
              </div>
            </div>

            <div>
              <label
                htmlFor="log-inspection-note"
                className="block text-xs font-semibold text-slate-700 mb-1"
              >
                Inspection &amp; Metrology Note
              </label>
              <textarea
                id="log-inspection-note"
                rows={3}
                value={logNote}
                onChange={(e) => setLogNote(e.target.value)}
                placeholder="e.g., Verified 8.1% timber moisture content; wedged tenon joints glued and clamped."
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-md text-slate-900 focus:outline-none focus:border-sky-600"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 px-4 text-xs font-semibold text-white bg-sky-600 hover:bg-sky-500 rounded-md transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              Append Workshop Record
            </button>
          </form>

          {/* Right: Chronological Log Entries */}
          <div className="lg:col-span-7 bg-white border border-slate-200 rounded-lg overflow-hidden divide-y divide-slate-200">
            <div className="p-4 bg-sky-50/70 flex items-center justify-between text-xs font-bold text-slate-800">
              <span>Chronological Atelier QC Ledger</span>
              <span className="font-mono tabular-nums text-sky-700">{workshopLogs.length} entries</span>
            </div>
            {workshopLogs.map((entry) => (
              <div key={entry.id} className="p-5 space-y-1.5 text-xs">
                <div className="flex flex-wrap items-center justify-between gap-2 text-slate-500">
                  <span>
                    <strong className="font-mono text-sky-700 tabular-nums">
                      {entry.orderId}
                    </strong>{' '}
                    · {entry.benchStation} · Artisan {entry.artisan}
                  </span>
                  <span className="font-mono tabular-nums">{entry.timestamp}</span>
                </div>
                <p className="text-sm text-slate-800 leading-relaxed">{entry.note}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* MODAL: Add New Furniture Catalog Record */}
      {isAddModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="add-furniture-modal-title"
        >
          <div className="w-full max-w-lg bg-slate-50 border border-sky-200 rounded-lg shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 bg-sky-50/80 border-b border-sky-200/80">
              <h2
                id="add-furniture-modal-title"
                className="font-display text-2xl font-bold text-slate-900"
              >
                Register New Furniture Catalog Record
              </h2>
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                aria-label="Close new furniture modal"
                className="p-1.5 text-slate-500 hover:text-slate-900 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateFurnitureRecord} className="p-6 space-y-4 text-xs">
              {addFormError && (
                <p className="text-xs text-red-700 bg-red-50 border border-red-200 rounded-md p-3">
                  {addFormError}
                </p>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label htmlFor="new-furn-name" className="block text-slate-700 font-semibold mb-1">
                    Furniture Piece Name
                  </label>
                  <input
                    id="new-furn-name"
                    type="text"
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    placeholder="e.g., Aurelia Travertine Console"
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-md text-slate-900 focus:outline-none focus:border-sky-600"
                  />
                </div>
                <div>
                  <label htmlFor="new-furn-sku" className="block text-slate-700 font-semibold mb-1">
                    SKU Code
                  </label>
                  <input
                    id="new-furn-sku"
                    type="text"
                    value={newSku}
                    onChange={(e) => setNewSku(e.target.value)}
                    placeholder="LR-LV-088"
                    className="w-full px-3 py-2 font-mono bg-white border border-slate-300 rounded-md text-slate-900 focus:outline-none focus:border-sky-600"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label htmlFor="new-furn-category" className="block text-slate-700 font-semibold mb-1">
                    Category
                  </label>
                  <select
                    id="new-furn-category"
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as CategoryId)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-md text-slate-900 focus:outline-none focus:border-sky-600"
                  >
                    {FURNITURE_CATEGORIES.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label htmlFor="new-furn-price" className="block text-slate-700 font-semibold mb-1">
                    Unit Price (USD)
                  </label>
                  <input
                    id="new-furn-price"
                    type="number"
                    value={newPrice}
                    onChange={(e) => setNewPrice(e.target.value)}
                    className="w-full px-3 py-2 font-mono bg-white border border-slate-300 rounded-md text-slate-900 focus:outline-none focus:border-sky-600"
                  />
                </div>
                <div>
                  <label htmlFor="new-furn-stock" className="block text-slate-700 font-semibold mb-1">
                    Initial Stock
                  </label>
                  <input
                    id="new-furn-stock"
                    type="number"
                    value={newStock}
                    onChange={(e) => setNewStock(e.target.value)}
                    className="w-full px-3 py-2 font-mono bg-white border border-slate-300 rounded-md text-slate-900 focus:outline-none focus:border-sky-600"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label htmlFor="new-furn-dims" className="block text-slate-700 font-semibold mb-1">
                    Architectural Dimensions
                  </label>
                  <input
                    id="new-furn-dims"
                    type="text"
                    value={newDimensions}
                    onChange={(e) => setNewDimensions(e.target.value)}
                    className="w-full px-3 py-2 font-mono bg-white border border-slate-300 rounded-md text-slate-900 focus:outline-none focus:border-sky-600"
                  />
                </div>
                <div>
                  <label htmlFor="new-furn-lead" className="block text-slate-700 font-semibold mb-1">
                    Lead Time (Weeks)
                  </label>
                  <input
                    id="new-furn-lead"
                    type="number"
                    value={newLeadWeeks}
                    onChange={(e) => setNewLeadWeeks(e.target.value)}
                    className="w-full px-3 py-2 font-mono bg-white border border-slate-300 rounded-md text-slate-900 focus:outline-none focus:border-sky-600"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="new-furn-finish" className="block text-slate-700 font-semibold mb-1">
                  Primary Timber / Upholstery Specification
                </label>
                <input
                  id="new-furn-finish"
                  type="text"
                  value={newFinish}
                  onChange={(e) => setNewFinish(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-md text-slate-900 focus:outline-none focus:border-sky-600"
                />
              </div>

              <div>
                <label htmlFor="new-furn-desc" className="block text-slate-700 font-semibold mb-1">
                  Showroom Specification Notes
                </label>
                <textarea
                  id="new-furn-desc"
                  rows={2}
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-md text-slate-900 focus:outline-none focus:border-sky-600"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 font-semibold text-slate-700 bg-white border border-slate-300 hover:border-slate-500 rounded-md cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 font-semibold text-white bg-sky-600 hover:bg-sky-500 rounded-md cursor-pointer"
                >
                  Save Catalog Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
