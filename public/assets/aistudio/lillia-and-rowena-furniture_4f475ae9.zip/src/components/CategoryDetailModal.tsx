import React, { useState, useEffect } from 'react';
import { X, Check, ArrowRight, Layers, Ruler, Clock, ShieldCheck } from 'lucide-react';
import {
  FurnitureCategory,
  FurnitureItem,
} from '../utils/furnitureStore';
import { ResilientImage } from './ResilientImage';

interface CategoryDetailModalProps {
  category: FurnitureCategory | null;
  categoryItems: FurnitureItem[];
  initialSelectedItem: FurnitureItem | null;
  onClose: () => void;
  onAddToOrder: (item: FurnitureItem, finish: string, quantity: number) => void;
}

export const CategoryDetailModal: React.FC<CategoryDetailModalProps> = ({
  category,
  categoryItems,
  initialSelectedItem,
  onClose,
  onAddToOrder,
}) => {
  const [activeItem, setActiveItem] = useState<FurnitureItem | null>(
    initialSelectedItem || categoryItems[0] || null
  );
  const [selectedFinish, setSelectedFinish] = useState<string>('');
  const [quantity, setQuantity] = useState<number>(1);
  const [justAdded, setJustAdded] = useState<boolean>(false);

  useEffect(() => {
    const target = initialSelectedItem || categoryItems[0] || null;
    setActiveItem(target);
    if (target) {
      setSelectedFinish(target.defaultFinish);
      setQuantity(1);
    }
    setJustAdded(false);
  }, [category, initialSelectedItem, categoryItems]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (!category && !activeItem) return null;

  const handleSelectPiece = (item: FurnitureItem) => {
    setActiveItem(item);
    setSelectedFinish(item.defaultFinish);
    setQuantity(1);
    setJustAdded(false);
  };

  const handleCommissionAdd = () => {
    if (!activeItem) return;
    onAddToOrder(activeItem, selectedFinish || activeItem.defaultFinish, quantity);
    setJustAdded(true);
    setTimeout(() => setJustAdded(false), 1800);
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#0D1015]/70 backdrop-blur-xs p-4 sm:p-6 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="category-modal-title"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-5xl rounded-2xl bg-[#F8FBFF] border border-[#BCE3FF] shadow-2xl overflow-hidden my-auto max-h-[90vh] flex flex-col"
      >
        {/* Top Modal Header */}
        <div className="flex items-center justify-between gap-4 px-6 py-5 surface-obsidian text-white border-b border-[#0095FF]/40 shrink-0">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-[#BCE3FF]">
              {category ? `Room Collection · ${category.leadTimeRange} Lead Time` : 'Showroom Specification Sheet'}
            </p>
            <h2
              id="category-modal-title"
              className="font-display text-2xl sm:text-3xl font-bold text-white mt-0.5"
            >
              {category ? category.name : activeItem?.name}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close furniture details modal"
            className="p-2 rounded-lg text-slate-300 hover:text-white hover:bg-[#0095FF] bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Modal Body */}
        <div className="overflow-y-auto p-6 sm:p-8 space-y-8">
          {/* Category Architectural Overview & Piece Selector Tabs */}
          {category && (
            <div className="border-b border-[#BCE3FF] pb-6 space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 space-y-2">
                  <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
                    {category.description}
                  </p>
                  <p className="text-xs text-slate-500">
                    Joinery Standard: {category.architecturalNote}
                  </p>
                </div>
                <div className="rounded-xl bg-[#BCE3FF]/45 p-4 border border-[#BCE3FF] space-y-1.5">
                  <p className="text-xs font-semibold uppercase tracking-wider text-[#0D1015]">
                    Primary Atelier Materials
                  </p>
                  <p className="text-xs text-slate-700 leading-relaxed">
                    {category.primaryMaterials.join(' · ')}
                  </p>
                </div>
              </div>

              {/* Piece Selector Switcher within Category */}
              <div className="pt-2">
                <p className="text-xs font-semibold text-[#0095FF] uppercase tracking-wider mb-2.5">
                  Select a piece in {category.name} ({categoryItems.length} pieces in archive):
                </p>
                <div className="flex flex-wrap gap-2">
                  {categoryItems.map((item) => {
                    const isSelected = activeItem?.id === item.id;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => handleSelectPiece(item)}
                        className={`px-3.5 py-2 text-xs font-semibold rounded-xl border transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                          isSelected
                            ? 'bg-[#0095FF] text-white border-[#0095FF] shadow-2xs'
                            : 'bg-white text-[#0D1015] border-[#BCE3FF] hover:bg-[#BCE3FF]/50'
                        }`}
                      >
                        {item.name} · <span className="font-mono tabular-nums">${item.price.toLocaleString()}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* Active Furniture Piece Specification & Contiguous Purchase Module */}
          {activeItem && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              {/* Left Column: Imagery & Craftsmanship Notes */}
              <div className="lg:col-span-6 space-y-5">
                <div className="aspect-[4/3] w-full overflow-hidden bg-slate-100 border border-[#BCE3FF] rounded-2xl">
                  <ResilientImage
                    src={activeItem.imageUrl}
                    alt={activeItem.name}
                    className="w-full h-full object-cover"
                  />
                </div>

                <div className="bg-[#BCE3FF]/35 p-5 border border-[#BCE3FF] rounded-2xl space-y-3">
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-[#0D1015]">
                    Atelier Construction &amp; Provenance
                  </h3>
                  <ul className="space-y-2 text-xs text-slate-700">
                    {activeItem.craftsmanshipDetails.map((detail, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="text-[#0095FF] select-none font-bold">—</span>
                        <span>{detail}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Right Column: Contiguous Specification & Commission Module */}
              <div className="lg:col-span-6 bg-white p-6 border border-slate-200 rounded-lg space-y-6">
                <div className="border-b border-slate-200 pb-4">
                  <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
                    <span className="font-mono tabular-nums text-blue-700 font-medium">SKU: {activeItem.sku}</span>
                    <span>·</span>
                    <span>{activeItem.categoryName}</span>
                    <span>·</span>
                    <span className="font-mono tabular-nums">
                      {activeItem.stockCount > 0
                        ? `${activeItem.stockCount} in showroom stock`
                        : 'Made to order'}
                    </span>
                  </div>
                  <h3 className="font-display text-2xl sm:text-3xl font-bold text-slate-900">
                    {activeItem.name}
                  </h3>
                  <div className="mt-2 flex flex-wrap items-baseline gap-3">
                    <span className="font-mono text-2xl font-bold text-slate-900 tabular-nums">
                      ${activeItem.price.toLocaleString()}
                    </span>
                    <span className="text-xs font-mono font-semibold text-amber-700 tabular-nums">
                      or ${Math.round(activeItem.price / 24)}/mo for 24 mos*
                    </span>
                  </div>
                </div>

                <p className="text-sm text-slate-600 leading-relaxed">
                  {activeItem.description}
                </p>

                {/* Technical Dimensions & Specs Grid */}
                <div className="grid grid-cols-2 gap-4 py-3 border-y border-slate-200 text-xs">
                  <div>
                    <span className="text-slate-500 flex items-center gap-1.5">
                      <Ruler className="w-3.5 h-3.5 text-blue-600" /> Dimensions
                    </span>
                    <p className="font-mono text-slate-900 mt-1 tabular-nums font-medium">
                      {activeItem.dimensions}
                    </p>
                  </div>
                  <div>
                    <span className="text-slate-500 flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-blue-600" /> Millwork Lead Time
                    </span>
                    <p className="font-mono text-slate-900 mt-1 tabular-nums font-medium">
                      {activeItem.leadTimeWeeks} Weeks ({activeItem.weightKg} kg)
                    </p>
                  </div>
                  <div className="col-span-2">
                    <span className="text-slate-500 flex items-center gap-1.5">
                      <Layers className="w-3.5 h-3.5 text-blue-600" /> Core Materials
                    </span>
                    <p className="text-slate-900 mt-1 font-medium">
                      {activeItem.materials.join(' · ')}
                    </p>
                  </div>
                </div>

                {/* Timber & Upholstery Finish Selector */}
                <div className="space-y-2">
                  <label
                    htmlFor="finish-select"
                    className="block text-xs font-semibold text-slate-800"
                  >
                    Select Timber &amp; Upholstery Finish
                  </label>
                  <select
                    id="finish-select"
                    value={selectedFinish}
                    onChange={(e) => setSelectedFinish(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-300 rounded-md text-slate-900 focus:outline-none focus:border-blue-600"
                  >
                    {activeItem.availableFinishes.map((fin) => (
                      <option key={fin} value={fin}>
                        {fin}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Quantity & Add to Commission Action */}
                <div className="flex flex-col sm:flex-row items-stretch sm:items-end gap-4 pt-2">
                  <div className="w-full sm:w-28">
                    <label
                      htmlFor="piece-quantity"
                      className="block text-xs font-semibold text-slate-800 mb-1.5"
                    >
                      Quantity
                    </label>
                    <input
                      id="piece-quantity"
                      type="number"
                      min={1}
                      max={20}
                      value={quantity}
                      onChange={(e) =>
                        setQuantity(Math.max(1, parseInt(e.target.value, 10) || 1))
                      }
                      className="w-full px-3 py-2 text-sm font-mono tabular-nums bg-slate-50 border border-slate-300 rounded-md text-slate-900 focus:outline-none focus:border-blue-600"
                    />
                  </div>

                  <button
                    type="button"
                    onClick={handleCommissionAdd}
                    className="flex-1 flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-md shadow-xs transition-colors cursor-pointer whitespace-nowrap shrink-0"
                  >
                    {justAdded ? (
                      <>
                        <Check className="w-4 h-4 text-amber-300" />
                        <span>Added to Order Inquiry</span>
                      </>
                    ) : (
                      <>
                        <span>
                          Add to Order Inquiry · ${(activeItem.price * quantity).toLocaleString()}
                        </span>
                        <ArrowRight className="w-4 h-4 text-amber-300" />
                      </>
                    )}
                  </button>
                </div>

                <div className="flex items-center gap-2 text-xs text-slate-500 pt-1">
                  <ShieldCheck className="w-4 h-4 text-amber-600 shrink-0" />
                  <span>
                    15-Year Structural Joinery Guarantee · Tracked in Client &amp; Admin Record Portals
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
