import React, { useState, useMemo } from 'react';
import {
  Search,
  ArrowUpRight,
  SlidersHorizontal,
  X,
  Plus,
  Eye,
  Compass,
  Star,
  Truck,
  ShieldCheck,
  CreditCard,
  Clock,
} from 'lucide-react';
import {
  CategoryId,
  FurnitureCategory,
  FurnitureItem,
  HERO_IMAGE_URL,
} from '../utils/furnitureStore';
import { ResilientImage } from './ResilientImage';

interface HomepageViewProps {
  categories: FurnitureCategory[];
  allItems: FurnitureItem[];
  filteredItems: FurnitureItem[];
  searchQuery: string;
  selectedCategoryFilter: CategoryId | 'all';
  onSearchChange: (q: string) => void;
  onCategoryFilterChange: (cat: CategoryId | 'all') => void;
  onOpenCategoryModal: (category: FurnitureCategory, initialItem?: FurnitureItem) => void;
  onOpenItemModal: (item: FurnitureItem) => void;
  onQuickAddToOrder: (item: FurnitureItem, selectedFinish?: string) => void;
  onNavigate: (view: 'home' | 'user-dashboard' | 'admin-dashboard' | 'login') => void;
}

type SortOption = 'featured' | 'price-asc' | 'price-desc' | 'lead-time';

export const HomepageView: React.FC<HomepageViewProps> = ({
  categories,
  allItems,
  filteredItems,
  searchQuery,
  selectedCategoryFilter,
  onSearchChange,
  onCategoryFilterChange,
  onOpenCategoryModal,
  onOpenItemModal,
  onQuickAddToOrder,
  onNavigate,
}) => {
  const [activeHeroSlide, setActiveHeroSlide] = useState<'flagship' | CategoryId>('flagship');
  const [sortBy, setSortBy] = useState<SortOption>('featured');
  const [cardFinishes, setCardFinishes] = useState<Record<string, string>>({});

  const quickSearchTerms = ['Walnut', 'Bouclé', 'Travertine', 'White Oak', 'Linen'];

  // Compute active hero showcase content based on selected room tab
  const currentHeroShowcase = useMemo(() => {
    if (activeHeroSlide === 'flagship') {
      return {
        kicker: '01. Flagship Home & Atelier Event · 0% APR for 24 Months',
        title: 'Sculptural Comfort Meets Heirloom Solid Timber.',
        subtitle:
          'Furnish every room with kiln-dried American black walnut, Belgian bouclé upholstery, and honed Roman travertine—backed by complimentary white-glove delivery and live order tracking.',
        imageUrl: HERO_IMAGE_URL,
        featuredLabel: 'Featured Room Package · Lillia Monolith Dining & Rowena Bouclé Salon',
        startingPrice: 1180,
        monthlyPrice: 49,
        targetCategory: categories[0],
      };
    }
    const foundCat = categories.find((c) => c.id === activeHeroSlide) || categories[0];
    const catPieces = allItems.filter((item) => item.categoryId === foundCat.id);
    const minPrice = catPieces.reduce(
      (min, p) => (p.price < min ? p.price : min),
      catPieces[0]?.price || 1200
    );
    return {
      kicker: `01. Room Collection Spotlight · ${foundCat.leadTimeRange} Delivery Window`,
      title: `${foundCat.name}: ${foundCat.tagline}.`,
      subtitle: foundCat.description,
      imageUrl: foundCat.imageUrl,
      featuredLabel: `${foundCat.architecturalNote}`,
      startingPrice: minPrice,
      monthlyPrice: Math.round(minPrice / 24),
      targetCategory: foundCat,
    };
  }, [activeHeroSlide, categories, allItems]);

  // Sorted catalog items
  const sortedItems = useMemo(() => {
    const copy = [...filteredItems];
    if (sortBy === 'price-asc') {
      copy.sort((a, b) => a.price - b.price);
    } else if (sortBy === 'price-desc') {
      copy.sort((a, b) => b.price - a.price);
    } else if (sortBy === 'lead-time') {
      copy.sort((a, b) => a.leadTimeWeeks - b.leadTimeWeeks);
    } else {
      copy.sort((a, b) => Number(Boolean(b.featured)) - Number(Boolean(a.featured)));
    }
    return copy;
  }, [filteredItems, sortBy]);

  return (
    <div className="space-y-20 pb-20">
      {/* SECTION 1: SLEEK OBSIDIAN & ELECTRIC AZURE FLAGSHIP HERO SHOWCASE */}
      <section className="surface-obsidian text-white border-b border-[#0095FF]/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 pb-12">
          {/* Interactive Segmented Room Switcher Bar */}
          <div className="flex flex-wrap items-center justify-between gap-4 pb-7 mb-8 border-b border-white/10">
            <div className="flex items-center gap-1.5 p-1 bg-white/5 border border-white/10 rounded-xl overflow-x-auto max-w-full">
              <button
                type="button"
                onClick={() => setActiveHeroSlide('flagship')}
                className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  activeHeroSlide === 'flagship'
                    ? 'bg-[#0095FF] text-white shadow-xs'
                    : 'text-slate-300 hover:text-[#BCE3FF]'
                }`}
              >
                Flagship Showroom
              </button>
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setActiveHeroSlide(cat.id)}
                  className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                    activeHeroSlide === cat.id
                      ? 'bg-[#0095FF] text-white shadow-xs'
                      : 'text-slate-300 hover:text-[#BCE3FF]'
                  }`}
                >
                  {cat.name}
                </button>
              ))}
            </div>

            <span className="text-xs text-[#BCE3FF] font-mono tabular-nums hidden lg:inline whitespace-nowrap shrink-0">
              Room Packages from ${currentHeroShowcase.startingPrice.toLocaleString()} or ${currentHeroShowcase.monthlyPrice}/mo
            </span>
          </div>

          {/* Editorial 12-Column Split Hero */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch">
            {/* Left Column: Editorial Headline, Ice-Blue & Azure Financing Card, Primary Actions */}
            <div className="lg:col-span-5 flex flex-col justify-between py-2 space-y-6">
              <div className="space-y-4">
                <p className="text-xs font-semibold tracking-wide text-[#BCE3FF]">
                  {currentHeroShowcase.kicker}
                </p>
                <h1 className="font-display text-4xl sm:text-5xl lg:text-[3.35rem] font-bold text-white leading-[1.06]">
                  {currentHeroShowcase.title}
                </h1>
                <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
                  {currentHeroShowcase.subtitle}
                </p>
              </div>

              <div className="space-y-5 pt-2">
                {/* Sleek Financing & Starting Price Card */}
                <div className="rounded-2xl bg-[#131922] border border-[#0095FF]/50 p-5 flex items-center justify-between gap-4 shadow-lg">
                  <div>
                    <p className="text-xs text-[#BCE3FF] font-medium">
                      Collection Starting At
                    </p>
                    <p className="font-mono text-3xl sm:text-4xl font-bold text-[#0095FF] tabular-nums mt-0.5">
                      ${currentHeroShowcase.startingPrice.toLocaleString()}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs font-semibold text-white font-mono tabular-nums">
                      Or ${currentHeroShowcase.monthlyPrice}/mo for 24 mos*
                    </p>
                    <p className="text-xs text-slate-400 mt-0.5">
                      0% APR Financing · Free White-Glove Delivery
                    </p>
                  </div>
                </div>

                {/* Primary & Secondary CTAs */}
                <div className="flex flex-wrap items-center gap-3">
                  <button
                    type="button"
                    onClick={() => onOpenCategoryModal(currentHeroShowcase.targetCategory)}
                    className="inline-flex items-center gap-2 px-5 py-3 text-xs sm:text-sm font-semibold text-white bg-[#0095FF] hover:bg-[#007ACC] rounded-xl shadow-sm transition-colors cursor-pointer whitespace-nowrap shrink-0"
                  >
                    <span>Explore {currentHeroShowcase.targetCategory.name}</span>
                    <ArrowUpRight className="w-4 h-4" />
                  </button>
                  <a
                    href="#category-grid"
                    className="inline-flex items-center gap-2 px-4 py-3 text-xs sm:text-sm font-semibold text-[#0D1015] bg-[#BCE3FF] hover:bg-white rounded-xl transition-colors whitespace-nowrap shrink-0"
                  >
                    <span>Browse Room Categories</span>
                  </a>
                  <button
                    type="button"
                    onClick={() => onNavigate('user-dashboard')}
                    className="inline-flex items-center gap-2 px-4 py-3 text-xs font-semibold text-[#BCE3FF] bg-white/5 border border-[#0095FF]/40 hover:bg-[#0095FF] hover:text-white rounded-xl transition-colors cursor-pointer whitespace-nowrap shrink-0"
                  >
                    <span>Track My Order</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Right Column: Sculpted Rounded-2xl Room Photography with Floating Glass Callout */}
            <div className="lg:col-span-7 relative rounded-2xl overflow-hidden border border-[#0095FF]/40 bg-slate-900 min-h-[340px] sm:min-h-[420px] flex flex-col justify-end shadow-2xl">
              <ResilientImage
                src={currentHeroShowcase.imageUrl}
                alt={currentHeroShowcase.title}
                className="absolute inset-0 w-full h-full object-cover"
              />
              <div className="relative z-10 bg-gradient-to-t from-[#0D1015]/95 via-[#0D1015]/60 to-transparent p-6 sm:p-8 pt-24 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
                <div className="space-y-1 max-w-lg">
                  <p className="text-xs font-medium text-[#BCE3FF]">
                    {currentHeroShowcase.featuredLabel} · {currentHeroShowcase.targetCategory.leadTimeRange} Lead Time
                  </p>
                  <p className="font-display text-2xl sm:text-3xl font-bold text-white">
                    {currentHeroShowcase.targetCategory.name} Showroom Collection
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => onOpenCategoryModal(currentHeroShowcase.targetCategory)}
                  className="self-start sm:self-auto px-4 py-2.5 text-xs font-semibold bg-[#0095FF] hover:bg-[#007ACC] text-white rounded-lg shadow-xs transition-colors cursor-pointer whitespace-nowrap shrink-0"
                >
                  Inspect Room Pieces
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Full-Width Ice-Blue Assurance Ribbon */}
        <div className="bg-[#BCE3FF] text-[#0D1015] border-t border-[#0095FF]/40">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="flex items-start gap-3">
              <CreditCard className="w-5 h-5 text-[#0095FF] shrink-0 mt-0.5" />
              <div>
                <p className="text-xs font-bold text-[#0D1015]">
                  0% APR for 24 Months
                </p>
                <p className="text-xs text-slate-700 mt-0.5">
                  Equal monthly payments on custom walnut, oak &amp; travertine
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Truck className="w-5 h-5 text-[#0095FF] shrink-0 mt-0.5" />
              <div>
                <p className="text-xs font-bold text-[#0D1015]">
                  Complimentary White-Glove Delivery
                </p>
                <p className="text-xs text-slate-700 mt-0.5">
                  In-room placement &amp; assembly included on orders $3,000+
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <ShieldCheck className="w-5 h-5 text-[#0095FF] shrink-0 mt-0.5" />
              <div>
                <p className="text-xs font-bold text-[#0D1015]">
                  15-Year Structural Joinery Warranty
                </p>
                <p className="text-xs text-slate-700 mt-0.5">
                  FAS-grade kiln-dried hardwoods at 8.2% moisture equilibrium
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Clock className="w-5 h-5 text-[#0095FF] shrink-0 mt-0.5" />
              <div>
                <p className="text-xs font-bold text-[#0D1015]">
                  Live 6-Stage Order Tracking
                </p>
                <p className="text-xs text-slate-700 mt-0.5">
                  Follow every commission from millwork bench to room delivery
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 2: SCULPTED PRODUCT CATEGORY SHOWCASE GRID */}
      <section id="category-grid" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-[#BCE3FF] pb-5">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-[#0095FF]">
              01. Curated Room Collections
            </p>
            <h2 className="font-display text-3xl sm:text-4xl font-bold text-[#0D1015] mt-1">
              Shop by Room &amp; Department
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-600 max-w-md">
            Click any room collection or individual piece below to inspect timber joinery, upholstery swatches, and architectural dimensions.
          </p>
        </div>

        {/* 4-Column Sculpted Department Gallery Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {categories.map((category) => {
            const piecesInCategory = allItems.filter(
              (item) => item.categoryId === category.id
            );
            const startingPrice = piecesInCategory.reduce(
              (min, p) => (p.price < min ? p.price : min),
              piecesInCategory[0]?.price || 0
            );

            return (
              <div
                key={category.id}
                className="group rounded-2xl bg-white border border-[#BCE3FF] hover:border-[#0095FF] shadow-xs hover:shadow-md flex flex-col justify-between overflow-hidden transition-all duration-150 hover:-translate-y-0.5"
              >
                <div>
                  {/* 4:3 Room Lifestyle Photography */}
                  <button
                    type="button"
                    onClick={() => onOpenCategoryModal(category)}
                    className="aspect-[4/3] w-full overflow-hidden bg-slate-100 relative block text-left cursor-pointer"
                  >
                    <ResilientImage
                      src={category.imageUrl}
                      alt={category.name}
                      className="w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-200"
                    />
                    <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-[#0D1015]/85 via-[#0D1015]/35 to-transparent p-4 flex items-end justify-between text-white">
                      <span className="text-xs font-medium text-[#BCE3FF]">
                        {piecesInCategory.length} Pieces · {category.leadTimeRange}
                      </span>
                      <span className="font-mono text-xs font-bold bg-[#0095FF] text-white px-2.5 py-1 rounded-md tabular-nums">
                        From ${startingPrice.toLocaleString()}
                      </span>
                    </div>
                  </button>

                  {/* Card Body */}
                  <div className="p-5 space-y-3">
                    <div>
                      <h3 className="font-display text-2xl font-bold text-[#0D1015] group-hover:text-[#0095FF] transition-colors">
                        {category.name}
                      </h3>
                      <p className="text-xs text-slate-600 mt-1 line-clamp-2 leading-relaxed">
                        {category.description}
                      </p>
                    </div>

                    {/* Interactive Piece List inside Category */}
                    <div className="rounded-xl bg-[#F4FAFF] border border-[#BCE3FF]/80 p-3 space-y-1.5">
                      <p className="text-[11px] font-semibold text-[#0095FF] uppercase tracking-wider">
                        Included Pieces (Click to Inspect):
                      </p>
                      <div className="divide-y divide-[#BCE3FF]/60">
                        {piecesInCategory.map((piece) => (
                          <button
                            key={piece.id}
                            type="button"
                            onClick={() => onOpenCategoryModal(category, piece)}
                            className="w-full flex items-center justify-between text-left text-xs py-1.5 hover:text-[#0095FF] transition-colors cursor-pointer"
                          >
                            <span className="font-medium text-slate-800 hover:text-[#0095FF] truncate pr-2">
                              {piece.name}
                            </span>
                            <span className="font-mono font-semibold text-[#0D1015] tabular-nums shrink-0">
                              ${piece.price.toLocaleString()}
                            </span>
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Card Footer Action */}
                <div className="px-5 pb-5 pt-1">
                  <button
                    type="button"
                    onClick={() => onOpenCategoryModal(category)}
                    className="w-full py-2.5 px-4 rounded-xl bg-[#BCE3FF]/55 hover:bg-[#0095FF] text-[#0D1015] hover:text-white font-semibold text-xs flex items-center justify-between transition-colors cursor-pointer"
                  >
                    <span>Explore {category.name} Details</span>
                    <ArrowUpRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* SECTION 3: UNIFIED SEARCH BAR & CURATED FURNITURE CATALOG */}
      <section id="catalog-search" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-[#BCE3FF] pb-5">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-[#0095FF]">
              02. Custom Millwork &amp; Ready-to-Ship Archive
            </p>
            <h2 className="font-display text-3xl sm:text-4xl font-bold text-[#0D1015] mt-1">
              Search &amp; Filter Furniture Collection
            </h2>
          </div>

          <div className="flex flex-wrap items-center gap-4">
            <p className="text-xs text-slate-600 font-mono tabular-nums">
              Showing {sortedItems.length} of {allItems.length} pieces
            </p>
            <div className="flex items-center gap-2 text-xs">
              <label htmlFor="catalog-sort-select" className="font-semibold text-slate-700">
                Sort by:
              </label>
              <select
                id="catalog-sort-select"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as SortOption)}
                className="px-3 py-1.5 text-xs bg-white border border-[#BCE3FF] rounded-lg text-[#0D1015] font-medium focus:outline-none focus:border-[#0095FF]"
              >
                <option value="featured">Featured Bestsellers</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
                <option value="lead-time">Fastest Delivery Window</option>
              </select>
            </div>
          </div>
        </div>

        {/* Ice-Blue Studio Search & Department Filter Dock */}
        <div className="rounded-2xl bg-white border border-[#BCE3FF] shadow-xs p-5 space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-center">
            {/* Search Input */}
            <div className="lg:col-span-5 relative">
              <label htmlFor="furniture-search-input" className="sr-only">
                Search furniture by name, timber, upholstery, or SKU
              </label>
              <Search className="w-4 h-4 text-[#0095FF] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                id="furniture-search-input"
                type="search"
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder="Search sofas, dining tables, walnut, bouclé, SKU..."
                className="w-full pl-10 pr-9 py-2.5 text-xs sm:text-sm bg-[#F4FAFF] border border-[#BCE3FF] rounded-xl text-[#0D1015] placeholder:text-slate-400 focus:bg-white focus:border-[#0095FF] focus:outline-none transition-colors"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => onSearchChange('')}
                  aria-label="Clear search query"
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-[#0D1015] cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Interactive Department Filter Tabs */}
            <div className="lg:col-span-7 flex items-center gap-1.5 overflow-x-auto pb-1 lg:pb-0 lg:justify-end">
              <SlidersHorizontal className="w-3.5 h-3.5 text-[#0095FF] mr-1 shrink-0 hidden sm:block" />
              <button
                type="button"
                onClick={() => onCategoryFilterChange('all')}
                className={`px-3.5 py-2 text-xs font-semibold rounded-xl transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  selectedCategoryFilter === 'all'
                    ? 'bg-[#0095FF] text-white shadow-2xs'
                    : 'bg-[#F4FAFF] text-slate-700 border border-[#BCE3FF] hover:bg-[#BCE3FF]/60'
                }`}
              >
                All ({allItems.length})
              </button>
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => onCategoryFilterChange(cat.id)}
                  className={`px-3.5 py-2 text-xs font-semibold rounded-xl transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                    selectedCategoryFilter === cat.id
                      ? 'bg-[#0095FF] text-white shadow-2xs'
                      : 'bg-[#F4FAFF] text-slate-700 border border-[#BCE3FF] hover:bg-[#BCE3FF]/60'
                  }`}
                >
                  {cat.name}
                </button>
              ))}
            </div>
          </div>

          {/* Quick Material Filter Bar */}
          <div className="flex flex-wrap items-center gap-2 pt-3 border-t border-[#BCE3FF]/60 text-xs">
            <span className="font-semibold text-slate-600">Popular Materials:</span>
            {quickSearchTerms.map((term) => (
              <button
                key={term}
                type="button"
                onClick={() =>
                  onSearchChange(searchQuery.toLowerCase() === term.toLowerCase() ? '' : term)
                }
                className={`px-3 py-1 text-xs rounded-lg border transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  searchQuery.toLowerCase() === term.toLowerCase()
                    ? 'bg-[#0095FF] text-white border-[#0095FF] font-semibold'
                    : 'bg-[#F4FAFF] text-slate-700 border-[#BCE3FF] hover:bg-[#BCE3FF]/60'
                }`}
              >
                {term}
              </button>
            ))}
          </div>
        </div>

        {/* 3-Column Sculpted Product Cards Grid */}
        {sortedItems.length === 0 ? (
          <div className="rounded-2xl bg-white border border-[#BCE3FF] p-12 text-center space-y-4">
            <Compass className="w-8 h-8 text-[#0095FF] mx-auto stroke-[1.5]" />
            <div className="space-y-1">
              <h3 className="font-display text-2xl font-bold text-[#0D1015]">
                No Matching Furniture Pieces Found
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 max-w-md mx-auto">
                No furniture records matched &ldquo;{searchQuery}&rdquo; in the selected department filter. Reset your filters to browse the full showroom collection.
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                onSearchChange('');
                onCategoryFilterChange('all');
              }}
              className="px-4 py-2 text-xs font-semibold text-white bg-[#0095FF] hover:bg-[#007ACC] rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              Reset Search &amp; Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {sortedItems.map((item, idx) => {
              const chosenFinish = cardFinishes[item.id] || item.defaultFinish;
              const monthlyPayment = Math.round(item.price / 24);
              const reviewCount = 24 + ((idx * 11) % 35);

              return (
                <article
                  key={item.id}
                  className="group rounded-2xl bg-white border border-[#BCE3FF] hover:border-[#0095FF] shadow-xs hover:shadow-md flex flex-col justify-between overflow-hidden transition-all duration-150 hover:-translate-y-0.5"
                >
                  <div>
                    {/* 4:3 Product Image */}
                    <button
                      type="button"
                      onClick={() => onOpenItemModal(item)}
                      className="aspect-[4/3] w-full overflow-hidden bg-slate-100 block text-left cursor-pointer relative"
                    >
                      <ResilientImage
                        src={item.imageUrl}
                        alt={item.name}
                        className="w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-200"
                      />
                    </button>

                    {/* Card Body */}
                    <div className="p-6 space-y-3">
                      {/* Unboxed Metadata Row */}
                      <div className="flex items-center justify-between text-xs text-slate-500">
                        <div className="flex items-center gap-1.5">
                          <span className="font-semibold text-[#0095FF]">{item.categoryName}</span>
                          <span aria-hidden="true">·</span>
                          <span className="font-mono tabular-nums">{item.sku}</span>
                        </div>
                        <span className="flex items-center gap-1 font-mono text-slate-700 tabular-nums">
                          <Star className="w-3.5 h-3.5 fill-[#0095FF] text-[#0095FF]" />
                          <span>4.9 ({reviewCount})</span>
                        </span>
                      </div>

                      <h3 className="font-display text-2xl font-bold text-[#0D1015] leading-snug group-hover:text-[#0095FF] transition-colors">
                        {item.name}
                      </h3>

                      <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                        {item.description}
                      </p>

                      {/* Interactive Finish Swatch Selector */}
                      <div className="pt-2 border-t border-[#BCE3FF]/60 space-y-1.5">
                        <p className="text-[11px] text-slate-500">
                          Selected Finish: <strong className="text-[#0D1015]">{chosenFinish}</strong>
                        </p>
                        <div className="flex flex-wrap gap-1.5">
                          {item.availableFinishes.map((fin) => {
                            const isSelected = chosenFinish === fin;
                            return (
                              <button
                                key={fin}
                                type="button"
                                onClick={() =>
                                  setCardFinishes((prev) => ({ ...prev, [item.id]: fin }))
                                }
                                className={`px-2.5 py-1 text-[11px] rounded-md border transition-colors cursor-pointer truncate max-w-[145px] ${
                                  isSelected
                                    ? 'bg-[#BCE3FF] border-[#0095FF] text-[#0D1015] font-semibold'
                                    : 'bg-[#F4FAFF] border-[#BCE3FF] text-slate-600 hover:border-[#0095FF]'
                                }`}
                              >
                                {fin.split('/')[0].trim()}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Price & Action Footer */}
                  <div className="px-6 pb-6 pt-2">
                    <div className="border-t border-[#BCE3FF]/80 pt-4 flex items-center justify-between gap-3">
                      <div>
                        <div className="flex items-baseline gap-2">
                          <span className="font-mono text-lg font-bold text-[#0D1015] tabular-nums">
                            ${item.price.toLocaleString()}
                          </span>
                          <span className="font-mono text-xs font-semibold text-[#0095FF] tabular-nums">
                            ${monthlyPayment}/mo*
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 font-mono tabular-nums">
                          {item.stockCount} in stock · {item.leadTimeWeeks}w delivery
                        </p>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => onOpenItemModal(item)}
                          className="inline-flex items-center gap-1 px-3 py-2 text-xs font-semibold text-[#0D1015] bg-[#BCE3FF]/60 hover:bg-[#BCE3FF] rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0"
                        >
                          <Eye className="w-3.5 h-3.5 text-[#0095FF]" />
                          <span>Details</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => onQuickAddToOrder(item, chosenFinish)}
                          aria-label={`Add ${item.name} to order inquiry`}
                          className="inline-flex items-center gap-1 px-3.5 py-2 text-xs font-semibold text-white bg-[#0095FF] hover:bg-[#007ACC] rounded-lg shadow-2xs transition-colors cursor-pointer whitespace-nowrap shrink-0"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>Add to Cart</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>

      {/* SECTION 4: SLEEK OBSIDIAN & ICE-BLUE ORDER PORTAL SHOWCASE BANNER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="rounded-3xl surface-obsidian text-white border border-[#0095FF]/40 p-8 sm:p-12 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center shadow-xl">
          <div className="lg:col-span-7 space-y-4">
            <p className="text-xs font-semibold uppercase tracking-wider text-[#BCE3FF]">
              03. Complimentary Design Services &amp; Live Order Record Tracking
            </p>
            <h2 className="font-display text-2xl sm:text-4xl font-bold text-white leading-snug">
              &ldquo;Every walnut slab and bouclé sofa we commissioned for One Rockwell was tracked down to the exact moisture reading and joinery bench in Lillia &amp; Rowena&rsquo;s portal.&rdquo;
            </h2>
            <p className="text-xs text-slate-300">
              Rowena Vance · Principal Architect, Vance &amp; Associates Spatial Design · Commissioned 14 custom residential pieces in 2026
            </p>
          </div>
          <div className="lg:col-span-5 flex flex-col sm:flex-row lg:flex-col gap-3 justify-end">
            <button
              type="button"
              onClick={() => onNavigate('user-dashboard')}
              className="px-5 py-3.5 text-xs sm:text-sm font-semibold text-white bg-[#0095FF] hover:bg-[#007ACC] rounded-xl shadow-sm transition-colors text-center cursor-pointer whitespace-nowrap shrink-0"
            >
              Track My Order · Client Dashboard
            </button>
            <button
              type="button"
              onClick={() => onNavigate('admin-dashboard')}
              className="px-5 py-3.5 text-xs sm:text-sm font-semibold text-[#0D1015] bg-[#BCE3FF] hover:bg-white rounded-xl transition-colors text-center cursor-pointer whitespace-nowrap shrink-0"
            >
              Open Atelier Admin Record Console
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
