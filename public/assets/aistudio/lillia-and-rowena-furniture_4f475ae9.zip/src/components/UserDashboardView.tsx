import React, { useState } from 'react';
import {
  Search,
  CheckCircle2,
  Clock,
  FileText,
  Save,
  Plus,
  Truck,
  Hammer,
} from 'lucide-react';
import {
  OrderRecord,
  ORDER_STATUS_STEPS,
  WorkshopLogEntry,
} from '../utils/furnitureStore';

interface UserDashboardViewProps {
  currentUserName: string;
  currentUserEmail: string;
  orders: OrderRecord[];
  workshopLogs: WorkshopLogEntry[];
  onUpdateOrderNotes: (orderId: string, updatedNotes: string, updatedAddress: string) => void;
  onNavigateToCatalog: () => void;
}

export const UserDashboardView: React.FC<UserDashboardViewProps> = ({
  currentUserName,
  currentUserEmail,
  orders,
  workshopLogs,
  onUpdateOrderNotes,
  onNavigateToCatalog,
}) => {
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'delivered'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedOrderId, setSelectedOrderId] = useState<string>(
    orders[0]?.id || ''
  );
  const [editingNotes, setEditingNotes] = useState<string>('');
  const [editingAddress, setEditingAddress] = useState<string>('');
  const [isEditingDelivery, setIsEditingDelivery] = useState(false);
  const [saveFeedback, setSaveFeedback] = useState<string | null>(null);

  const filteredOrders = orders.filter((order) => {
    const matchesStatus =
      statusFilter === 'all'
        ? true
        : statusFilter === 'active'
        ? order.status !== 'Delivered'
        : order.status === 'Delivered';

    if (!matchesStatus) return false;
    if (!searchQuery.trim()) return true;

    const q = searchQuery.trim().toLowerCase();
    const itemNames = order.items.map((i) => `${i.name} ${i.sku} ${i.finish}`).join(' ');
    return (
      order.id.toLowerCase().includes(q) ||
      order.clientName.toLowerCase().includes(q) ||
      order.status.toLowerCase().includes(q) ||
      itemNames.toLowerCase().includes(q)
    );
  });

  const activeOrder =
    orders.find((o) => o.id === selectedOrderId) || filteredOrders[0] || orders[0] || null;

  const activeStepIndex = activeOrder
    ? ORDER_STATUS_STEPS.indexOf(activeOrder.status)
    : 0;

  const orderLogs = activeOrder
    ? workshopLogs.filter((log) => log.orderId === activeOrder.id)
    : [];

  const totalClientSpend = orders.reduce((sum, o) => sum + o.totalAmount, 0);
  const inProductionCount = orders.filter((o) => o.status !== 'Delivered').length;
  const deliveredCount = orders.filter((o) => o.status === 'Delivered').length;

  const handleStartEditDelivery = (order: OrderRecord) => {
    setEditingNotes(order.notes);
    setEditingAddress(order.shippingAddress);
    setIsEditingDelivery(true);
    setSaveFeedback(null);
  };

  const handleSaveDeliveryUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeOrder) return;
    onUpdateOrderNotes(activeOrder.id, editingNotes.trim(), editingAddress.trim());
    setIsEditingDelivery(false);
    setSaveFeedback('Delivery instructions & site record updated.');
    setTimeout(() => setSaveFeedback(null), 3000);
  };

  return (
    <div className="max-w-7xl mx-auto px-6 lg:px-8 py-10 space-y-10">
      {/* Header & Client Identity Breadcrumb */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-[#BCE3FF] pb-6">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-[#0095FF]">
            Client Order Tracking · Bespoke Commission &amp; Delivery Ledger
          </p>
          <h1 className="font-display text-3xl sm:text-4xl font-bold text-[#0D1015] mt-1">
            Client Order &amp; Specification Dashboard
          </h1>
          <p className="text-xs text-slate-600 mt-1">
            Account Holder: <span className="font-semibold text-[#0D1015]">{currentUserName}</span> · {currentUserEmail}
          </p>
        </div>

        <button
          type="button"
          onClick={onNavigateToCatalog}
          className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-white bg-[#0095FF] hover:bg-[#007ACC] rounded-xl shadow-2xs transition-colors cursor-pointer whitespace-nowrap shrink-0 self-start md:self-auto"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Shop &amp; Commission New Piece</span>
        </button>
      </div>

      {/* 4-Column Client KPI Summary */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 rounded-2xl bg-white border border-[#BCE3FF] shadow-xs p-6">
        <div className="border-r border-[#BCE3FF]/60 pr-4">
          <p className="text-xs font-medium text-slate-500">Total Commissioned Value</p>
          <p className="font-mono text-2xl font-bold text-[#0D1015] mt-1 tabular-nums">
            ${totalClientSpend.toLocaleString()}
          </p>
          <p className="text-xs text-slate-500 mt-0.5 font-mono tabular-nums">
            {orders.length} registered order records
          </p>
        </div>
        <div className="lg:border-r border-[#BCE3FF]/60 lg:pr-4">
          <p className="text-xs font-medium text-slate-500">Active Millwork Commissions</p>
          <p className="font-mono text-2xl font-bold text-[#0095FF] mt-1 tabular-nums">
            {inProductionCount}
          </p>
          <p className="text-xs text-slate-500 mt-0.5">
            In joinery, finishing, or QC
          </p>
        </div>
        <div className="border-r border-[#BCE3FF]/60 pr-4">
          <p className="text-xs font-medium text-slate-500">Completed White-Glove Deliveries</p>
          <p className="font-mono text-2xl font-bold text-emerald-600 mt-1 tabular-nums">
            {deliveredCount}
          </p>
          <p className="text-xs text-slate-500 mt-0.5">
            15-year structural warranty active
          </p>
        </div>
        <div>
          <p className="text-xs font-medium text-slate-500">Next Scheduled Dispatch</p>
          <p className="font-mono text-xl font-bold text-[#0D1015] mt-1 tabular-nums">
            {activeOrder ? activeOrder.estimatedDelivery : 'None Pending'}
          </p>
          <p className="text-xs text-[#0095FF] font-semibold mt-0.5 font-mono tabular-nums">
            {activeOrder ? `Order ${activeOrder.id}` : 'All orders fulfilled'}
          </p>
        </div>
      </div>

      {/* Main Split Workspace: Left Order List & Filter, Right Selected Order Milestone & Record Sheet */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column (5 cols): Filterable Client Orders List */}
        <div className="lg:col-span-5 space-y-4">
          <div className="rounded-2xl bg-white border border-[#BCE3FF] p-4 space-y-3 shadow-2xs">
            <div className="relative">
              <label htmlFor="user-order-search" className="sr-only">
                Search orders by ID, piece name, or finish
              </label>
              <Search className="w-4 h-4 text-[#0095FF] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                id="user-order-search"
                type="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search order ID, walnut, sofa..."
                className="w-full pl-9 pr-3 py-2 text-xs bg-[#F4FAFF] border border-[#BCE3FF] rounded-xl text-[#0D1015] focus:bg-white focus:border-[#0095FF] focus:outline-none"
              />
            </div>

            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setStatusFilter('all')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  statusFilter === 'all'
                    ? 'bg-[#0095FF] text-white'
                    : 'bg-[#F4FAFF] text-slate-700 border border-[#BCE3FF] hover:bg-[#BCE3FF]/50'
                }`}
              >
                All Orders ({orders.length})
              </button>
              <button
                type="button"
                onClick={() => setStatusFilter('active')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  statusFilter === 'active'
                    ? 'bg-[#0095FF] text-white'
                    : 'bg-[#F4FAFF] text-slate-700 border border-[#BCE3FF] hover:bg-[#BCE3FF]/50'
                }`}
              >
                In Production ({inProductionCount})
              </button>
              <button
                type="button"
                onClick={() => setStatusFilter('delivered')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  statusFilter === 'delivered'
                    ? 'bg-[#0095FF] text-white'
                    : 'bg-[#F4FAFF] text-slate-700 border border-[#BCE3FF] hover:bg-[#BCE3FF]/50'
                }`}
              >
                Delivered ({deliveredCount})
              </button>
            </div>
          </div>

          {/* Orders List */}
          <div className="space-y-3">
            {filteredOrders.map((ord) => {
              const isSelected = activeOrder?.id === ord.id;
              return (
                <button
                  key={ord.id}
                  type="button"
                  onClick={() => {
                    setSelectedOrderId(ord.id);
                    setIsEditingDelivery(false);
                    setSaveFeedback(null);
                  }}
                  className={`w-full text-left p-5 rounded-2xl border transition-all cursor-pointer block ${
                    isSelected
                      ? 'bg-[#BCE3FF]/35 border-[#0095FF] shadow-xs'
                      : 'bg-white border-[#BCE3FF] hover:border-[#0095FF]'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs text-slate-500">
                    <span className="font-mono font-bold text-sky-700 tabular-nums">
                      {ord.id}
                    </span>
                    <span className="font-mono tabular-nums">
                      Ordered {ord.createdAt}
                    </span>
                  </div>

                  <p className="text-sm font-bold text-slate-900 mt-1.5">
                    {ord.items.map((i) => `${i.quantity}× ${i.name}`).join(', ')}
                  </p>

                  <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                    <span className="flex items-center gap-1.5 text-slate-700">
                      {ord.status === 'Delivered' ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      ) : (
                        <Clock className="w-3.5 h-3.5 text-sky-600" />
                      )}
                      <span className="font-medium">{ord.status}</span>
                      <span aria-hidden="true">·</span>
                      <span className="text-slate-500">{ord.paymentStatus}</span>
                    </span>
                    <span className="font-mono font-bold text-slate-900 tabular-nums">
                      ${ord.totalAmount.toLocaleString()}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Column (7 cols): Detailed Order Specification & Production Milestone Inspector */}
        <div className="lg:col-span-7">
          {activeOrder ? (
            <div className="bg-white border border-slate-200 rounded-lg p-6 sm:p-8 space-y-8">
              {/* Record Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-5">
                <div>
                  <div className="flex items-center gap-2 text-xs text-slate-500">
                    <span className="font-mono font-bold text-sky-700 tabular-nums">
                      {activeOrder.id}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>Client: {activeOrder.clientName}</span>
                    <span aria-hidden="true">·</span>
                    <span>Lead Joiner: {activeOrder.craftspersonAssigned}</span>
                  </div>
                  <h2 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 mt-1">
                    Production &amp; White-Glove Record
                  </h2>
                </div>

                <div className="text-left sm:text-right">
                  <p className="text-xs text-slate-500">Estimated Delivery</p>
                  <p className="font-mono text-base font-bold text-sky-700 tabular-nums">
                    {activeOrder.estimatedDelivery}
                  </p>
                </div>
              </div>

              {/* 6-Stage Atelier Production Timeline */}
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-900 flex items-center gap-1.5">
                    <Hammer className="w-3.5 h-3.5 text-sky-600" /> 6-Stage Millwork &amp; Dispatch Progress
                  </span>
                  <span className="font-mono text-sky-700 font-medium tabular-nums">
                    Stage {activeStepIndex + 1} of {ORDER_STATUS_STEPS.length}: {activeOrder.status}
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 pt-1">
                  {ORDER_STATUS_STEPS.map((step, index) => {
                    const isCompleted = index <= activeStepIndex;
                    const isCurrent = index === activeStepIndex;
                    return (
                      <div
                        key={step}
                        className={`p-2.5 border rounded-md text-xs ${
                          isCurrent
                            ? 'bg-sky-600 text-white border-sky-600 shadow-2xs'
                            : isCompleted
                            ? 'bg-sky-50 text-sky-900 border-sky-200'
                            : 'bg-white text-slate-400 border-slate-200'
                        }`}
                      >
                        <p className="font-mono text-[11px] tabular-nums opacity-75">
                          0{index + 1}
                        </p>
                        <p className="font-semibold mt-0.5 leading-tight">{step}</p>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Itemized Commission Breakdown */}
              <div className="space-y-3">
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5 text-sky-600" /> Itemized Furniture Specifications
                </h3>
                <div className="border border-slate-200 rounded-lg overflow-hidden divide-y divide-slate-200">
                  {activeOrder.items.map((item, idx) => (
                    <div
                      key={`${item.furnitureId}-${idx}`}
                      className="p-4 flex items-center justify-between gap-4 text-xs"
                    >
                      <div className="space-y-0.5">
                        <p className="text-sm font-bold text-slate-900">
                          {item.name}
                        </p>
                        <p className="text-slate-500">
                          SKU: <span className="font-mono tabular-nums text-sky-700">{item.sku}</span> · Finish: {item.finish}
                        </p>
                      </div>
                      <div className="text-right font-mono tabular-nums shrink-0">
                        <p className="text-sm font-bold text-slate-900">
                          ${(item.unitPrice * item.quantity).toLocaleString()}
                        </p>
                        <p className="text-slate-500">
                          Qty {item.quantity} × ${item.unitPrice.toLocaleString()}
                        </p>
                      </div>
                    </div>
                  ))}
                  <div className="p-4 bg-sky-50/70 flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-700">
                      Total Recorded Commission ({activeOrder.paymentStatus})
                    </span>
                    <span className="font-mono text-base font-bold text-slate-900 tabular-nums">
                      ${activeOrder.totalAmount.toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>

              {/* Bench Log Entries for This Order */}
              {orderLogs.length > 0 && (
                <div className="space-y-2">
                  <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                    Atelier Bench Inspection Logs
                  </h3>
                  <div className="bg-slate-50 border border-slate-200 rounded-lg divide-y divide-slate-200 text-xs">
                    {orderLogs.map((log) => (
                      <div key={log.id} className="p-3.5 space-y-1">
                        <div className="flex items-center justify-between text-slate-500">
                          <span className="text-sky-700 font-medium">
                            {log.benchStation} · Artisan {log.artisan}
                          </span>
                          <span className="font-mono tabular-nums">{log.timestamp}</span>
                        </div>
                        <p className="text-slate-800">{log.note}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Site Delivery & Architectural Instructions Record (Editable by Client) */}
              <div className="border-t border-slate-200 pt-6 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                    <Truck className="w-3.5 h-3.5 text-sky-600" /> White-Glove Delivery &amp; Site Access Record
                  </h3>
                  {!isEditingDelivery && (
                    <button
                      type="button"
                      onClick={() => handleStartEditDelivery(activeOrder)}
                      className="px-3 py-1.5 text-xs font-semibold text-sky-900 bg-sky-50 border border-sky-200 hover:bg-sky-100 rounded-md transition-colors cursor-pointer whitespace-nowrap shrink-0"
                    >
                      Edit Site Instructions
                    </button>
                  )}
                </div>

                {saveFeedback && (
                  <p className="text-xs text-sky-800 bg-sky-50 border border-sky-200 rounded-md p-3">
                    {saveFeedback}
                  </p>
                )}

                {isEditingDelivery ? (
                  <form onSubmit={handleSaveDeliveryUpdate} className="space-y-4 bg-slate-50 p-4 border border-slate-200 rounded-lg">
                    <div>
                      <label
                        htmlFor="edit-delivery-address"
                        className="block text-xs font-semibold text-slate-700 mb-1"
                      >
                        Delivery Destination Address
                      </label>
                      <input
                        id="edit-delivery-address"
                        type="text"
                        value={editingAddress}
                        onChange={(e) => setEditingAddress(e.target.value)}
                        className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-md text-slate-900 focus:outline-none focus:border-sky-600"
                      />
                    </div>
                    <div>
                      <label
                        htmlFor="edit-delivery-notes"
                        className="block text-xs font-semibold text-slate-700 mb-1"
                      >
                        Architectural Site &amp; Finish Notes
                      </label>
                      <textarea
                        id="edit-delivery-notes"
                        rows={3}
                        value={editingNotes}
                        onChange={(e) => setEditingNotes(e.target.value)}
                        className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-md text-slate-900 focus:outline-none focus:border-sky-600"
                      />
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        type="submit"
                        className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-sky-600 hover:bg-sky-500 rounded-md transition-colors cursor-pointer whitespace-nowrap shrink-0"
                      >
                        <Save className="w-3.5 h-3.5" />
                        <span>Save Updated Record</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setIsEditingDelivery(false)}
                        className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:border-slate-500 rounded-md transition-colors cursor-pointer whitespace-nowrap shrink-0"
                      >
                        Cancel
                      </button>
                    </div>
                  </form>
                ) : (
                  <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 space-y-2 text-xs">
                    <p className="text-slate-500">
                      Destination: <span className="text-slate-900 font-semibold">{activeOrder.shippingAddress}</span> · Contact: <span className="font-mono tabular-nums text-slate-800">{activeOrder.clientPhone}</span>
                    </p>
                    <p className="text-slate-700 leading-relaxed">
                      Notes: {activeOrder.notes}
                    </p>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="bg-white border border-slate-200 rounded-lg p-12 text-center">
              <p className="text-sm text-slate-600">
                Select an order record on the left to inspect its millwork timeline and specifications.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
