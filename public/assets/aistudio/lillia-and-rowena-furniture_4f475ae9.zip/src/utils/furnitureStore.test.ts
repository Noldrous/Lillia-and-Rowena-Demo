import test from 'node:test';
import assert from 'node:assert/strict';
import {
  INITIAL_FURNITURE_ITEMS,
  INITIAL_ORDER_RECORDS,
  filterFurnitureItems,
  calculateOrderPricing,
  validateLoginCredentials,
  computeDashboardMetrics,
  validateNewFurnitureInput,
} from './furnitureStore';

test('filterFurnitureItems filters by search query across materials, SKU, and name', () => {
  const walnutResults = filterFurnitureItems(INITIAL_FURNITURE_ITEMS, 'walnut', 'all');
  assert.ok(walnutResults.length >= 3, 'Should find multiple walnut furniture items');

  const diningMonolithSuite = filterFurnitureItems(INITIAL_FURNITURE_ITEMS, 'monolith', 'dining');
  assert.equal(diningMonolithSuite.length, 2);

  const exactSkuMatch = filterFurnitureItems(INITIAL_FURNITURE_ITEMS, 'LR-DN-108', 'dining');
  assert.equal(exactSkuMatch.length, 1);
  assert.equal(exactSkuMatch[0].sku, 'LR-DN-108');

  const wrongCategory = filterFurnitureItems(INITIAL_FURNITURE_ITEMS, 'monolith', 'bedroom');
  assert.equal(wrongCategory.length, 0);
});

test('calculateOrderPricing applies free white-glove delivery at or above $3,000', () => {
  const smallOrder = calculateOrderPricing([{ unitPrice: 2150, quantity: 1 }]);
  assert.equal(smallOrder.subtotal, 2150);
  assert.equal(smallOrder.whiteGloveFee, 180);
  assert.equal(smallOrder.totalAmount, 2330);
  assert.equal(smallOrder.depositRequired, 1165);

  const largeOrder = calculateOrderPricing([{ unitPrice: 4200, quantity: 1 }]);
  assert.equal(largeOrder.subtotal, 4200);
  assert.equal(largeOrder.whiteGloveFee, 0);
  assert.equal(largeOrder.totalAmount, 4200);
  assert.equal(largeOrder.depositRequired, 2100);
});

test('validateLoginCredentials rejects empty inputs and identifies admin vs client roles', () => {
  const emptyCheck = validateLoginCredentials('', 'password123');
  assert.equal(emptyCheck.valid, false);

  const adminCheck = validateLoginCredentials('lillia@lilliarowena.com', 'atelier2026');
  assert.equal(adminCheck.valid, true);
  assert.equal(adminCheck.role, 'admin');

  const clientCheck = validateLoginCredentials('rowena.vance@vancearchitects.com', 'client2026');
  assert.equal(clientCheck.valid, true);
  assert.equal(clientCheck.role, 'client');
});

test('computeDashboardMetrics aggregates revenue, active production, and stock alerts', () => {
  const metrics = computeDashboardMetrics(INITIAL_ORDER_RECORDS, INITIAL_FURNITURE_ITEMS);
  assert.equal(metrics.totalRevenue, 27210);
  assert.equal(metrics.activeProductionCount, 4);
  assert.equal(metrics.completedCount, 1);
  assert.ok(metrics.lowStockItemCount >= 2);
});

test('validateNewFurnitureInput enforces required fields', () => {
  const invalid = validateNewFurnitureInput({
    name: '',
    sku: 'LR-TEST-01',
    categoryId: 'living',
    price: 1500,
    dimensions: '100cm x 50cm x 40cm',
    defaultFinish: 'White Oak',
    stockCount: 2,
  });
  assert.equal(invalid.valid, false);

  const valid = validateNewFurnitureInput({
    name: 'Solstice Travertine Side Table',
    sku: 'LR-LV-099',
    categoryId: 'living',
    price: 980,
    dimensions: '45cm W × 45cm D × 50cm H',
    defaultFinish: 'Honed Travertine',
    stockCount: 5,
  });
  assert.equal(valid.valid, true);
});
