export type CategoryId = 'living' | 'dining' | 'bedroom' | 'office';

export type OrderStatus =
  | 'Order Confirmed'
  | 'In Millwork'
  | 'Hand Finishing'
  | 'Quality Inspection'
  | 'White-Glove Dispatched'
  | 'Delivered';

export type PaymentStatus = 'Deposit Paid (50%)' | 'Paid in Full' | 'Invoice Pending';

export interface FurnitureCategory {
  id: CategoryId;
  name: string;
  tagline: string;
  description: string;
  imageUrl: string;
  architecturalNote: string;
  leadTimeRange: string;
  primaryMaterials: string[];
}

export interface FurnitureItem {
  id: string;
  sku: string;
  name: string;
  categoryId: CategoryId;
  categoryName: string;
  price: number;
  dimensions: string;
  materials: string[];
  defaultFinish: string;
  availableFinishes: string[];
  stockCount: number;
  leadTimeWeeks: number;
  weightKg: number;
  description: string;
  craftsmanshipDetails: string[];
  imageUrl: string;
  featured?: boolean;
}

export interface OrderRecord {
  id: string;
  clientName: string;
  clientEmail: string;
  clientPhone: string;
  shippingAddress: string;
  createdAt: string;
  estimatedDelivery: string;
  status: OrderStatus;
  paymentStatus: PaymentStatus;
  items: {
    furnitureId: string;
    sku: string;
    name: string;
    finish: string;
    quantity: number;
    unitPrice: number;
  }[];
  subtotal: number;
  whiteGloveFee: number;
  totalAmount: number;
  craftspersonAssigned: string;
  notes: string;
}

export interface WorkshopLogEntry {
  id: string;
  timestamp: string;
  orderId: string;
  benchStation: string;
  artisan: string;
  note: string;
}

export const HERO_IMAGE_URL =
  '/src/assets/images/hero_living_room_atelier_1794398505361.jpg';

export const FURNITURE_CATEGORIES: FurnitureCategory[] = [
  {
    id: 'living',
    name: 'Living & Lounge',
    tagline: 'Sculptural seating & travertine plinths',
    description:
      'Low-slung architectural silhouettes upholstered in heavyweight Belgian linen and nubby wool bouclé, paired with kiln-dried white oak lounge frames and honed Italian travertine surfaces.',
    imageUrl: '/src/assets/images/category_living_lounge_1794398506494.jpg',
    architecturalNote: 'Mortise-and-tenon solid hardwood frames with 8-way hand-tied suspension',
    leadTimeRange: '3–6 Weeks',
    primaryMaterials: ['Heavyweight Oat Bouclé', 'Kiln-Dried White Oak', 'Honed Roman Travertine'],
  },
  {
    id: 'dining',
    name: 'Dining & Tables',
    tagline: 'Solid timber gathering tables & woven seating',
    description:
      'Heirloom dining tables milled from FAS-grade American black walnut and European white oak slabs, finished with hand-rubbed organic linseed oil and paired with Danish paper-cord chairs.',
    imageUrl: '/src/assets/images/category_dining_tables_1794398508447.jpg',
    architecturalNote: 'Exposed wedged through-tenon joinery allowing seasonal timber movement',
    leadTimeRange: '4–8 Weeks',
    primaryMaterials: ['American Black Walnut', 'Danish Paper Cord', 'Hand-Rubbed Tung Oil'],
  },
  {
    id: 'bedroom',
    name: 'Bedroom Sanctuary',
    tagline: 'Upholstered platform beds & floating casegoods',
    description:
      'Quiet, grounding sleep architecture featuring Belgian flax linen headboards, solid ash timber platform rails, and cantilevered bedside tables with soft-close dovetail drawers.',
    imageUrl: '/src/assets/images/category_bedroom_sanctuary_1794398508886.jpg',
    architecturalNote: 'Zero-hardware interlocking Japanese timber rail joinery',
    leadTimeRange: '3–5 Weeks',
    primaryMaterials: ['Unbleached Belgian Linen', 'Solid European Ash', 'Brushed Unlacquered Brass'],
  },
  {
    id: 'office',
    name: 'Study & Credenzas',
    tagline: 'Executive writing desks & fluted architectural storage',
    description:
      'Commanding writing desks and custom-milled fluted credenzas engineered with concealed cable channels, solid brass hardware, and book-matched walnut veneer interiors.',
    imageUrl: '/src/assets/images/category_office_storage_1794398510414.jpg',
    architecturalNote: 'Hand-fitted English dovetail drawers and book-matched continuous grain',
    leadTimeRange: '2–6 Weeks',
    primaryMaterials: ['Fluted Black Walnut', 'Quarter-Sawn White Oak', 'Cast Architectural Bronze'],
  },
];

export const INITIAL_FURNITURE_ITEMS: FurnitureItem[] = [
  {
    id: 'furn-101',
    sku: 'LR-LV-014',
    name: 'Rowena Curved Bouclé Atelier Sofa',
    categoryId: 'living',
    categoryName: 'Living & Lounge',
    price: 4850,
    dimensions: '240cm W × 104cm D × 74cm H',
    materials: ['Belgian Wool Bouclé', 'Kiln-Dried White Oak Plinth'],
    defaultFinish: 'Warm Oat Bouclé / Natural Oak',
    availableFinishes: [
      'Warm Oat Bouclé / Natural Oak',
      'Alabaster Heavy Linen / Smoked Oak',
      'Raw Umber Wool / American Walnut',
    ],
    stockCount: 4,
    leadTimeWeeks: 4,
    weightKg: 82,
    description:
      'A sweeping crescent silhouette engineered for conversational salon layouts. Built over a solid kiln-dried white oak plinth with multi-density natural latex and down-wrapped cushions.',
    craftsmanshipDetails: [
      'Hand-upholstered in our Manila & Cebu partner millwork studio',
      'FSC-certified solid white oak concealed base with adjustable floor glides',
      'Stain-resistant natural wool bouclé woven in Belgium (65,000 Martindale rubs)',
    ],
    imageUrl: '/src/assets/images/category_living_lounge_1794398506494.jpg',
    featured: true,
  },
  {
    id: 'furn-102',
    sku: 'LR-LV-029',
    name: 'Cavana Sculpted White Oak Lounge Chair',
    categoryId: 'living',
    categoryName: 'Living & Lounge',
    price: 1680,
    dimensions: '72cm W × 76cm D × 75cm H',
    materials: ['Quarter-Sawn White Oak', 'Saddle Leather Sling'],
    defaultFinish: 'Soap-Finished White Oak',
    availableFinishes: [
      'Soap-Finished White Oak',
      'Fumed Dark Oak',
      'Oiled Black Walnut',
    ],
    stockCount: 9,
    leadTimeWeeks: 2,
    weightKg: 19,
    description:
      'Steam-bent armrests flow seamlessly into tapered rear legs via precision finger-jointed transitions. Equally suited as a reading chair or architectural pair.',
    craftsmanshipDetails: [
      '5-axis CNC pre-shaped and hand-rasped for organic tactile transitions',
      'Zero-VOC hardwax oil finish that deepens in patina over time',
      'Ergonomic 105-degree reclined seat pitch',
    ],
    imageUrl: '/src/assets/images/category_living_lounge_1794398506494.jpg',
    featured: false,
  },
  {
    id: 'furn-103',
    sku: 'LR-LV-042',
    name: 'Verona Honed Travertine Plinth Table',
    categoryId: 'living',
    categoryName: 'Living & Lounge',
    price: 2350,
    dimensions: '150cm W × 80cm D × 34cm H',
    materials: ['Solid Roman Travertine', 'Recessed Bronze Dowels'],
    defaultFinish: 'Unfilled Matte Travertine',
    availableFinishes: [
      'Unfilled Matte Travertine',
      'Honed Warm Limestone',
      'Resin-Filled Smooth Travertine',
    ],
    stockCount: 3,
    leadTimeWeeks: 3,
    weightKg: 96,
    description:
      'Cut from monolithic blocks of porous Roman travertine with a softly bullnosed organic top resting on two offset architectural column cylinders.',
    craftsmanshipDetails: [
      'Hand-honed stone edges with breathable penetrating sealer',
      'Dry-fit interlocking pin system for safe white-glove installation',
      'Each slab exhibits unique geological veining and natural cavities',
    ],
    imageUrl: '/src/assets/images/category_living_lounge_1794398506494.jpg',
    featured: false,
  },
  {
    id: 'furn-201',
    sku: 'LR-DN-108',
    name: 'Lillia Monolith Solid Walnut Dining Table',
    categoryId: 'dining',
    categoryName: 'Dining & Tables',
    price: 4200,
    dimensions: '240cm W × 105cm D × 75cm H',
    materials: ['FAS-Grade Black Walnut', 'Brass Butterfly Keys'],
    defaultFinish: 'Hand-Rubbed Natural Walnut',
    availableFinishes: [
      'Hand-Rubbed Natural Walnut',
      'Quarter-Sawn White Oak',
      'Ebonized Ash Timber',
    ],
    stockCount: 5,
    leadTimeWeeks: 5,
    weightKg: 110,
    description:
      'Our flagship dining table featuring a 45mm thick book-matched walnut slab top with a subtle live-inspired chamfered edge and sculptural trestle stretchers.',
    craftsmanshipDetails: [
      'Accommodates 8 to 10 guests comfortably with generous leg clearance',
      'Exposed wedged mortise-and-tenon trestle base engineered for generational stability',
      'Finished with 6 coats of food-safe polymerized tung oil and beeswax',
    ],
    imageUrl: '/src/assets/images/category_dining_tables_1794398508447.jpg',
    featured: true,
  },
  {
    id: 'furn-202',
    sku: 'LR-DN-115',
    name: 'Solenne Woven Cord Dining Chair (Set of 2)',
    categoryId: 'dining',
    categoryName: 'Dining & Tables',
    price: 1290,
    dimensions: '54cm W × 52cm D × 78cm H',
    materials: ['Solid Black Walnut', '3-Ply Danish Paper Cord'],
    defaultFinish: 'Oiled Walnut / Natural Cord',
    availableFinishes: [
      'Oiled Walnut / Natural Cord',
      'White Oak / Natural Cord',
      'Walnut / Black Woven Cord',
    ],
    stockCount: 14,
    leadTimeWeeks: 2,
    weightKg: 12,
    description:
      'Hand-woven over four hours using 130 meters of wax-coated Danish paper cord per seat. Designed to tuck flush beneath the Lillia Monolith Dining Table.',
    craftsmanshipDetails: [
      'Steam-bent curved backrest conforms naturally to the lumbar spine',
      'Envelope-weave seat rated for 25+ years of daily residential or hospitality use',
      'Sold as a matched pair milled from the same timber boule',
    ],
    imageUrl: '/src/assets/images/category_dining_tables_1794398508447.jpg',
    featured: false,
  },
  {
    id: 'furn-301',
    sku: 'LR-BD-204',
    name: 'Serene Belgian Linen Platform Bed (King)',
    categoryId: 'bedroom',
    categoryName: 'Bedroom Sanctuary',
    price: 3650,
    dimensions: '206cm W × 224cm D × 102cm H',
    materials: ['Belgian Flax Linen', 'Solid European Ash Frame'],
    defaultFinish: 'Oatmeal Flax Linen / Ash Base',
    availableFinishes: [
      'Oatmeal Flax Linen / Ash Base',
      'Warm Stone Linen / Walnut Base',
      'Chalk Bouclé / White Oak Base',
    ],
    stockCount: 6,
    leadTimeWeeks: 4,
    weightKg: 94,
    description:
      'Architectural low-profile platform bed with removable tailored Belgian linen upholstery and solid ash European slat support requiring no box spring.',
    craftsmanshipDetails: [
      'Japanese-inspired interlocking corner joinery eliminates creaks and visible bolts',
      'Breathable solid ash posture slats spaced at 5cm intervals',
      'Includes recessed solid timber plinth for an airy floating visual footprint',
    ],
    imageUrl: '/src/assets/images/category_bedroom_sanctuary_1794398508886.jpg',
    featured: true,
  },
  {
    id: 'furn-302',
    sku: 'LR-BD-219',
    name: 'Cantilevered Ash Bedside Nightstand (Pair)',
    categoryId: 'bedroom',
    categoryName: 'Bedroom Sanctuary',
    price: 1180,
    dimensions: '55cm W × 40cm D × 24cm H',
    materials: ['Solid European Ash', 'Cedar-Lined Dovetail Drawer'],
    defaultFinish: 'Natural Matte Ash',
    availableFinishes: [
      'Natural Matte Ash',
      'Oiled Black Walnut',
      'Smoked White Oak',
    ],
    stockCount: 8,
    leadTimeWeeks: 2,
    weightKg: 22,
    description:
      'Wall-mounted floating bedside cases with mitered waterfall grain wrap, aromatic Spanish cedar drawer bottoms, and concealed rear cord pass-throughs.',
    craftsmanshipDetails: [
      'French cleat solid hardwood mounting bracket rated to 65kg',
      'Blum undermount soft-close slides with traditional half-blind dovetails',
      'Delivered as a left-and-right book-matched pair',
    ],
    imageUrl: '/src/assets/images/category_bedroom_sanctuary_1794398508886.jpg',
    featured: false,
  },
  {
    id: 'furn-401',
    sku: 'LR-OF-302',
    name: 'Mercier Fluted Walnut Sideboard Credenza',
    categoryId: 'office',
    categoryName: 'Study & Credenzas',
    price: 3890,
    dimensions: '200cm W × 48cm D × 76cm H',
    materials: ['Solid Fluted Black Walnut', 'Unlacquered Cast Brass'],
    defaultFinish: 'Natural Walnut / Aged Brass',
    availableFinishes: [
      'Natural Walnut / Aged Brass',
      'White Oak / Brushed Bronze',
      'Ebonized Oak / Matte Brass',
    ],
    stockCount: 4,
    leadTimeWeeks: 4,
    weightKg: 88,
    description:
      'Rhythmic half-round solid walnut reeds across four seamless cabinet doors conceal adjustable shelving, velvet-lined flatware trays, and media ventilation.',
    craftsmanshipDetails: [
      'Custom sand-cast solid brass pulls forged exclusively for Lillia & Rowena',
      'Sequential grain-matched doors milled from a single log',
      'Integrated magnetic touch latches and acoustic felt door dampeners',
    ],
    imageUrl: '/src/assets/images/category_office_storage_1794398510414.jpg',
    featured: true,
  },
  {
    id: 'furn-402',
    sku: 'LR-OF-315',
    name: 'Atelier Quarter-Sawn Oak Writing Desk',
    categoryId: 'office',
    categoryName: 'Study & Credenzas',
    price: 2150,
    dimensions: '160cm W × 75cm D × 75cm H',
    materials: ['Quarter-Sawn White Oak', 'Full-Grain Leather Drawer Mat'],
    defaultFinish: 'Natural White Oak / Brass Pulls',
    availableFinishes: [
      'Natural White Oak / Brass Pulls',
      'American Black Walnut / Bronze Pulls',
    ],
    stockCount: 7,
    leadTimeWeeks: 3,
    weightKg: 54,
    description:
      'A serene architectural worktable with dual flush-front stationery drawers, vegetable-tanned leather interior liners, and a hidden rear power trough.',
    craftsmanshipDetails: [
      'Medullary ray fleck pattern characteristic of true quarter-sawn oak',
      'Mortised stretcher base offers rigid lateral stability',
      'Ships fully assembled or flat-packed for narrow stairwell access',
    ],
    imageUrl: '/src/assets/images/category_office_storage_1794398510414.jpg',
    featured: false,
  },
];

export const INITIAL_ORDER_RECORDS: OrderRecord[] = [
  {
    id: 'ORD-2026-841',
    clientName: 'Rowena Vance',
    clientEmail: 'rowena.vance@vancearchitects.com',
    clientPhone: '+63 917 482 9104',
    shippingAddress: 'Unit 14B, One Rockwell East Tower, Makati City',
    createdAt: '2026-10-24',
    estimatedDelivery: '2026-11-28',
    status: 'Hand Finishing',
    paymentStatus: 'Paid in Full',
    items: [
      {
        furnitureId: 'furn-201',
        sku: 'LR-DN-108',
        name: 'Lillia Monolith Solid Walnut Dining Table',
        finish: 'Hand-Rubbed Natural Walnut',
        quantity: 1,
        unitPrice: 4200,
      },
      {
        furnitureId: 'furn-202',
        sku: 'LR-DN-115',
        name: 'Solenne Woven Cord Dining Chair (Set of 2)',
        finish: 'Oiled Walnut / Natural Cord',
        quantity: 2,
        unitPrice: 1290,
      },
    ],
    subtotal: 6780,
    whiteGloveFee: 0,
    totalAmount: 6780,
    craftspersonAssigned: 'Master Joiner Mateo Reyes',
    notes: 'Service elevator reserved for Saturday morning window. Apply extra coat of matte tung oil on tabletop.',
  },
  {
    id: 'ORD-2026-839',
    clientName: 'Rowena Vance',
    clientEmail: 'rowena.vance@vancearchitects.com',
    clientPhone: '+63 917 482 9104',
    shippingAddress: 'Unit 14B, One Rockwell East Tower, Makati City',
    createdAt: '2026-09-12',
    estimatedDelivery: '2026-10-19',
    status: 'Delivered',
    paymentStatus: 'Paid in Full',
    items: [
      {
        furnitureId: 'furn-102',
        sku: 'LR-LV-029',
        name: 'Cavana Sculpted White Oak Lounge Chair',
        finish: 'Soap-Finished White Oak',
        quantity: 2,
        unitPrice: 1680,
      },
    ],
    subtotal: 3360,
    whiteGloveFee: 0,
    totalAmount: 3360,
    craftspersonAssigned: 'Artisan Clara Solis',
    notes: 'Delivered and inspected with signed white-glove placement checklist.',
  },
  {
    id: 'ORD-2026-845',
    clientName: 'Julianna Del Rosario',
    clientEmail: 'j.delrosario@studioayala.ph',
    clientPhone: '+63 918 609 3321',
    shippingAddress: '48 Narra Road, Forbes Park, Makati City',
    createdAt: '2026-11-02',
    estimatedDelivery: '2026-12-06',
    status: 'In Millwork',
    paymentStatus: 'Deposit Paid (50%)',
    items: [
      {
        furnitureId: 'furn-101',
        sku: 'LR-LV-014',
        name: 'Rowena Curved Bouclé Atelier Sofa',
        finish: 'Warm Oat Bouclé / Natural Oak',
        quantity: 1,
        unitPrice: 4850,
      },
      {
        furnitureId: 'furn-103',
        sku: 'LR-LV-042',
        name: 'Verona Honed Travertine Plinth Table',
        finish: 'Unfilled Matte Travertine',
        quantity: 1,
        unitPrice: 2350,
      },
    ],
    subtotal: 7200,
    whiteGloveFee: 0,
    totalAmount: 7200,
    craftspersonAssigned: 'Master Upholsterer Rafael Lim',
    notes: 'Architect requested fabric swatch verification before final cushion seaming.',
  },
  {
    id: 'ORD-2026-848',
    clientName: 'Marcus & Elena Tantoco',
    clientEmail: 'elena@tantocoholdings.com',
    clientPhone: '+63 917 811 2049',
    shippingAddress: 'Lot 9, Ayala Alabang Village, Muntinlupa',
    createdAt: '2026-11-06',
    estimatedDelivery: '2026-12-10',
    status: 'Quality Inspection',
    paymentStatus: 'Paid in Full',
    items: [
      {
        furnitureId: 'furn-301',
        sku: 'LR-BD-204',
        name: 'Serene Belgian Linen Platform Bed (King)',
        finish: 'Oatmeal Flax Linen / Ash Base',
        quantity: 1,
        unitPrice: 3650,
      },
      {
        furnitureId: 'furn-401',
        sku: 'LR-OF-302',
        name: 'Mercier Fluted Walnut Sideboard Credenza',
        finish: 'Natural Walnut / Aged Brass',
        quantity: 1,
        unitPrice: 3890,
      },
    ],
    subtotal: 7540,
    whiteGloveFee: 0,
    totalAmount: 7540,
    craftspersonAssigned: 'Master Joiner Mateo Reyes',
    notes: 'Final moisture content verification completed at 8.2% equilibrium.',
  },
  {
    id: 'ORD-2026-850',
    clientName: 'Henrik Lindqvist',
    clientEmail: 'henrik@nordichouse.sg',
    clientPhone: '+65 8129 4401',
    shippingAddress: '18 Nassim Hill, #04-02, Singapore',
    createdAt: '2026-11-09',
    estimatedDelivery: '2026-12-18',
    status: 'Order Confirmed',
    paymentStatus: 'Deposit Paid (50%)',
    items: [
      {
        furnitureId: 'furn-402',
        sku: 'LR-OF-315',
        name: 'Atelier Quarter-Sawn Oak Writing Desk',
        finish: 'Natural White Oak / Brass Pulls',
        quantity: 1,
        unitPrice: 2150,
      },
    ],
    subtotal: 2150,
    whiteGloveFee: 180,
    totalAmount: 2330,
    craftspersonAssigned: 'Artisan Clara Solis',
    notes: 'Export crating with ISPM-15 heat-treated timber frame scheduled.',
  },
];

export const INITIAL_WORKSHOP_LOGS: WorkshopLogEntry[] = [
  {
    id: 'LOG-901',
    timestamp: '2026-11-11 09:40',
    orderId: 'ORD-2026-841',
    benchStation: 'Finishing Bay 02',
    artisan: 'Mateo Reyes',
    note: 'Applied 4th coat of polymerized tung oil on 240cm walnut slab; wet-sanded to 600 grit.',
  },
  {
    id: 'LOG-902',
    timestamp: '2026-11-10 16:15',
    orderId: 'ORD-2026-848',
    benchStation: 'QC Metrology Bench',
    artisan: 'Lillia Mercier',
    note: 'Inspected fluted walnut doors and solid brass pulls; drawer reveal tolerance within 0.5mm.',
  },
  {
    id: 'LOG-903',
    timestamp: '2026-11-10 11:20',
    orderId: 'ORD-2026-845',
    benchStation: 'Millwork & CNC Bay 01',
    artisan: 'Rafael Lim',
    note: 'Completed curved white oak plinth laminations; Belgian wool bouclé bolts arrived from Antwerp.',
  },
];

export const ORDER_STATUS_STEPS: OrderStatus[] = [
  'Order Confirmed',
  'In Millwork',
  'Hand Finishing',
  'Quality Inspection',
  'White-Glove Dispatched',
  'Delivered',
];

/**
 * Pure function to filter furniture items by search query and optional category ID.
 */
export function filterFurnitureItems(
  items: FurnitureItem[],
  searchQuery: string,
  categoryId: CategoryId | 'all' = 'all'
): FurnitureItem[] {
  const normalizedQuery = searchQuery.trim().toLowerCase();
  return items.filter((item) => {
    const matchesCategory = categoryId === 'all' || item.categoryId === categoryId;
    if (!matchesCategory) return false;
    if (!normalizedQuery) return true;

    const searchableText = [
      item.name,
      item.sku,
      item.categoryName,
      item.description,
      item.defaultFinish,
      ...item.materials,
      ...item.availableFinishes,
    ]
      .join(' ')
      .toLowerCase();

    return searchableText.includes(normalizedQuery);
  });
}

/**
 * Pure function to calculate subtotal, white-glove delivery fee (free for orders >= $3,000), and total.
 */
export function calculateOrderPricing(
  items: { unitPrice: number; quantity: number }[]
): { subtotal: number; whiteGloveFee: number; totalAmount: number; depositRequired: number } {
  const subtotal = items.reduce(
    (sum, item) => sum + Math.max(0, item.unitPrice) * Math.max(0, item.quantity),
    0
  );
  const whiteGloveFee = subtotal === 0 ? 0 : subtotal >= 3000 ? 0 : 180;
  const totalAmount = subtotal + whiteGloveFee;
  const depositRequired = Math.round(totalAmount * 0.5);

  return { subtotal, whiteGloveFee, totalAmount, depositRequired };
}

/**
 * Validates login input without silently substituting fallback credentials.
 */
export function validateLoginCredentials(
  email: string,
  password: string
): { valid: boolean; error?: string; role?: 'client' | 'admin'; displayName?: string } {
  const trimmedEmail = email.trim().toLowerCase();
  const trimmedPass = password.trim();

  if (!trimmedEmail) {
    return { valid: false, error: 'Please enter your registered email address.' };
  }
  if (!trimmedEmail.includes('@') || !trimmedEmail.includes('.')) {
    return { valid: false, error: 'Please enter a valid email address format.' };
  }
  if (!trimmedPass || trimmedPass.length < 4) {
    return { valid: false, error: 'Please enter your password (minimum 4 characters).' };
  }

  if (
    trimmedEmail.includes('admin') ||
    trimmedEmail.includes('lillia') ||
    trimmedEmail === 'atelier@lilliarowena.com'
  ) {
    return {
      valid: true,
      role: 'admin',
      displayName: 'Lillia Mercier (Head of Atelier Admin)',
    };
  }

  return {
    valid: true,
    role: 'client',
    displayName: trimmedEmail.includes('rowena') ? 'Rowena Vance' : trimmedEmail.split('@')[0],
  };
}

/**
 * Computes Admin & Atelier summary KPIs from current orders and furniture catalog.
 */
export function computeDashboardMetrics(
  orders: OrderRecord[],
  catalog: FurnitureItem[]
): {
  totalRevenue: number;
  activeProductionCount: number;
  completedCount: number;
  lowStockItemCount: number;
  totalCatalogStock: number;
} {
  const totalRevenue = orders.reduce((sum, ord) => sum + ord.totalAmount, 0);
  const activeProductionCount = orders.filter((ord) => ord.status !== 'Delivered').length;
  const completedCount = orders.filter((ord) => ord.status === 'Delivered').length;
  const lowStockItemCount = catalog.filter((item) => item.stockCount <= 4).length;
  const totalCatalogStock = catalog.reduce((sum, item) => sum + item.stockCount, 0);

  return {
    totalRevenue,
    activeProductionCount,
    completedCount,
    lowStockItemCount,
    totalCatalogStock,
  };
}

/**
 * Validates new furniture record creation in the Admin Dashboard.
 */
export function validateNewFurnitureInput(input: {
  name: string;
  sku: string;
  categoryId: CategoryId;
  price: number;
  dimensions: string;
  defaultFinish: string;
  stockCount: number;
}): { valid: boolean; error?: string } {
  if (!input.name.trim()) {
    return { valid: false, error: 'Furniture title is required.' };
  }
  if (!input.sku.trim()) {
    return { valid: false, error: 'Catalog SKU code is required.' };
  }
  if (!Number.isFinite(input.price) || input.price <= 0) {
    return { valid: false, error: 'Price must be greater than $0.' };
  }
  if (!input.dimensions.trim()) {
    return { valid: false, error: 'Architectural dimensions are required.' };
  }
  if (!input.defaultFinish.trim()) {
    return { valid: false, error: 'Primary timber or upholstery finish is required.' };
  }
  if (!Number.isFinite(input.stockCount) || input.stockCount < 0) {
    return { valid: false, error: 'Stock count must be 0 or greater.' };
  }
  return { valid: true };
}
